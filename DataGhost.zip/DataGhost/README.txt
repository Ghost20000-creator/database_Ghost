Data Ghost - Android project (version 2.0)

BUILD THE APK
1) Android Studio: open this folder, then Build > Build APK(s).
2) No Android Studio: use GitHub Actions (see build.yml next to this zip).

ADDING FILES
- Inside the app: Add file -> pick any file from the phone (db, sqlite, mdb, accdb, accdr, xls, xlsx, csv, txt ...).
  The format is detected from the file content, not from the extension. Several files can be picked at once.
- Inside the APK: put files in assets/ (any folder). They are imported automatically the first time the app runs.

HOW THE SEARCH IS FAST
Every file is read once and turned into a private index (SQLite FTS4) plus a compact record store.
Importing runs in a foreground service, so large files keep importing when the app is closed.
A search then asks the index for matching record numbers and reads only those records: milliseconds,
even for millions of rows. Words are matched as word starts; numbers match with or without country code
or leading zero; Arabic letters are normalized (alef variants, ya, ta marbuta, diacritics).
If the index finds nothing, the app automatically scans the full text; the Deep search button does the same on demand.

SETTINGS
app/src/main/java/com/ghost/dataghost/Config.kt
  CHANNEL_URL        the channel opened by the Subscribe button
  GATE_EVERY_LAUNCH  true = ask on every launch, false = until Subscribe is pressed once
  MAX_RESULTS        results shown per search
