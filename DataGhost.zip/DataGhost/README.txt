Data Ghost - Android project

BUILD THE APK
1) Android Studio: open this folder, then Build > Build APK(s).
2) No Android Studio: use GitHub Actions (see build.yml next to this zip).

ADD YOUR DATA (inside the finished APK)
Put the files in assets/data/ (or assets/) with any name. Each file appears in the app by its name.
Supported: db sqlite mdb accdb accdr access xls xlsx csv txt. The format is detected from the file
content, not from the extension.

SETTINGS
app/src/main/java/com/ghost/dataghost/Config.kt
  CHANNEL_URL        the channel opened by the Subscribe button
  GATE_EVERY_LAUNCH  true = ask on every launch, false = until Subscribe is pressed once
  MAX_RESULTS        results shown per search
