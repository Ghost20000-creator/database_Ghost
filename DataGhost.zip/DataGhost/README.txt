Data Ghost - Android project (version 3.0)

BUILD THE APK
1) Android Studio: open this folder, then Build > Build APK(s).
2) No Android Studio: use GitHub Actions (see build.yml next to this zip).

ADDING FILES
- Inside the app: Add file -> pick any file from the phone (db, sqlite, mdb, accdb, accdr, xls, xlsx, csv, txt ...).
  The format is detected from the file content, not from the extension. Several files can be picked at once.
- Inside the APK: put files in assets/ (any folder). They are imported automatically the first time the app runs.

HOW THE IMPORT AND THE SEARCH WORK (version 3)
Import is ONE sequential pass: records are stored as they are, and one entry (hash of a word, record number)
per distinct word is written into 128 temporary files; then every temporary file is sorted in memory and appended
to index.bin. No database is used, so millions of rows import in minutes. It runs in a foreground service,
so large files keep importing when the app is closed.
Search hashes the typed words, finds their entries with a binary search directly on index.bin, intersects the
record numbers and reads only those records. Every result is re-checked against the real record text.
- Whole words (and numbers, with or without country code / leading zero) are found instantly.
- Words that are too common (about 1.5 million rows or more) are skipped by the index; the search then relies on
  the other words, or on the deep scan.
- If the index finds nothing (for example a part of a word), the app scans the full text automatically, using all
  processor cores. The Deep search button does the same on demand and finds text anywhere, even inside a word.
- Arabic letters are normalized (alef variants, ya, ta marbuta, diacritics).

SETTINGS
app/src/main/java/com/ghost/dataghost/Config.kt
  CHANNEL_URL        the channel opened by the Subscribe button
  GATE_EVERY_LAUNCH  true = ask on every launch, false = until Subscribe is pressed once
  MAX_RESULTS        results shown per search
