package com.ghost.dataghost

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteStatement
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.util.TreeSet
import java.util.concurrent.atomic.AtomicBoolean

/*
 * Every imported file becomes a "dataset" folder inside the app's private storage:
 *   meta.json     name, format, state, row count, column titles of every table/sheet
 *   records.bin   all records, one after another:  [length][tableNumber 0x1E field 0x1F field ...]
 *   offs.bin      8 bytes per record: where that record starts inside records.bin
 *   index.db      SQLite full-text index (FTS4, no copy of the text) -> record number
 * A search asks the index for record numbers, then reads only those records from records.bin.
 */

class TableInfo(val name: String, val headers: List<String>)

class Meta(
    val id: String,
    var name: String,
    var origin: String,
    var stamp: Long,
    var fmt: String,
    var state: String,
    var rows: Long,
    var error: String,
    var created: Long,
    var tables: List<TableInfo>
)

object Datasets {
    fun root(ctx: Context): File = File(ctx.filesDir, "datasets")

    fun dir(ctx: Context, id: String): File = File(root(ctx), id)

    fun create(ctx: Context, m: Meta) {
        val d = dir(ctx, m.id)
        d.mkdirs()
        write(d, m)
    }

    fun write(dir: File, m: Meta) {
        val tables = JSONArray()
        for (t in m.tables) {
            tables.put(JSONObject().put("n", t.name).put("h", JSONArray(t.headers)))
        }
        val o = JSONObject()
        o.put("id", m.id)
        o.put("name", m.name)
        o.put("origin", m.origin)
        o.put("stamp", m.stamp)
        o.put("fmt", m.fmt)
        o.put("state", m.state)
        o.put("rows", m.rows)
        o.put("error", m.error)
        o.put("created", m.created)
        o.put("tables", tables)
        val tmp = File(dir, "meta.json.tmp")
        tmp.writeText(o.toString())
        tmp.renameTo(File(dir, "meta.json"))
    }

    fun read(dir: File): Meta? {
        return try {
            val o = JSONObject(File(dir, "meta.json").readText())
            val ts = ArrayList<TableInfo>()
            val ja = o.optJSONArray("tables")
            if (ja != null) {
                for (i in 0 until ja.length()) {
                    val to = ja.getJSONObject(i)
                    val ha = to.getJSONArray("h")
                    val hs = ArrayList<String>()
                    for (k in 0 until ha.length()) hs.add(ha.getString(k))
                    ts.add(TableInfo(to.getString("n"), hs))
                }
            }
            Meta(
                o.getString("id"), o.getString("name"), o.getString("origin"), o.optLong("stamp"),
                o.optString("fmt"), o.getString("state"), o.optLong("rows"), o.optString("error"),
                o.optLong("created"), ts
            )
        } catch (e: Exception) {
            null
        }
    }

    fun list(ctx: Context): List<Meta> {
        val out = ArrayList<Meta>()
        val dirs = root(ctx).listFiles() ?: return out
        for (d in dirs) {
            if (!d.isDirectory) continue
            val m = read(d)
            if (m != null) out.add(m)
        }
        out.sortBy { it.name.lowercase() }
        return out
    }

    fun delete(ctx: Context, id: String) {
        dir(ctx, id).deleteRecursively()
    }

    fun diskSize(ctx: Context, id: String): Long {
        val d = dir(ctx, id)
        return File(d, "records.bin").length() + File(d, "offs.bin").length() + File(d, "index.db").length()
    }
}

// ---------------------------------------------------------------------------------------------
// Writing: records + full-text index, built in one pass while the file is read
// ---------------------------------------------------------------------------------------------

class DatasetWriter(
    ctx: Context,
    private val meta: Meta,
    private val prog: Importer.Prog,
    private val note: (Int) -> Unit
) : RecordSink {
    private val dir = Datasets.dir(ctx, meta.id)
    private val rec = BufferedOutputStream(FileOutputStream(File(dir, "records.bin")), 1 shl 20)
    private val offs = BufferedOutputStream(FileOutputStream(File(dir, "offs.bin")), 1 shl 18)
    private lateinit var db: SQLiteDatabase
    private lateinit var ins: SQLiteStatement
    private val tables = ArrayList<TableInfo>()
    private var cur = 0
    private var pos = 0L
    private var count = 0L
    private val offBuf = ByteArray(8)
    private val sb = StringBuilder()
    private var inTx = false

    init {
        try {
            val f = File(dir, "index.db")
            f.delete()
            db = SQLiteDatabase.openOrCreateDatabase(f.path, null)
            pragma("PRAGMA journal_mode=OFF")
            pragma("PRAGMA synchronous=OFF")
            pragma("PRAGMA cache_size=-32768")
            try {
                db.execSQL("CREATE VIRTUAL TABLE fts USING fts4(content=\"\", t, tokenize=unicode61)")
            } catch (e: Exception) {
                db.execSQL("DROP TABLE IF EXISTS fts")
                db.execSQL("CREATE VIRTUAL TABLE fts USING fts4(content=\"\", t)")
            }
            ins = db.compileStatement("INSERT INTO fts(docid, t) VALUES(?, ?)")
            db.beginTransaction()
            inTx = true
        } catch (e: Throwable) {
            try {
                rec.close()
            } catch (x: Exception) {
            }
            try {
                offs.close()
            } catch (x: Exception) {
            }
            throw e
        }
    }

    private fun pragma(sql: String) {
        try {
            val c = db.rawQuery(sql, null)
            try {
                c.moveToFirst()
            } finally {
                c.close()
            }
        } catch (e: Exception) {
            // a speed setting that this phone refuses only makes the import a little slower
        }
    }

    override fun table(name: String, headers: List<String>) {
        tables.add(TableInfo(name, ArrayList(headers)))
        cur = tables.size - 1
    }

    override fun cancelled(): Boolean = prog.cancel

    override fun bytes(n: Long) {
        prog.done = n
    }

    override fun record(fields: List<String>) {
        var lastNon = -1
        for (i in fields.indices) {
            if (fields[i].isNotBlank()) lastNon = i
        }
        if (lastNon < 0) return
        if (tables.isEmpty()) table("", emptyList())

        sb.setLength(0)
        sb.append(cur).append('\u001E')
        for (i in 0..lastNon) {
            if (i > 0) sb.append('\u001F')
            var f = fields[i].trim()
            if (f.indexOf('\u001F') >= 0 || f.indexOf('\u001E') >= 0) {
                f = f.replace('\u001F', ' ').replace('\u001E', ' ')
            }
            sb.append(f)
        }
        val bytes = sb.toString().toByteArray(Charsets.UTF_8)

        // where this record starts
        var v = pos
        for (k in 7 downTo 0) {
            offBuf[k] = (v and 0xFFL).toByte()
            v = v ushr 8
        }
        offs.write(offBuf)

        // the record itself: length (varint) + bytes
        var len = bytes.size
        var written = 0
        while (len >= 0x80) {
            rec.write((len and 0x7F) or 0x80)
            len = len ushr 7
            written++
        }
        rec.write(len)
        written++
        rec.write(bytes)
        pos += (written + bytes.size).toLong()
        count++

        // the search index
        ins.bindLong(1, count)
        ins.bindString(2, Norm.indexText(fields))
        ins.execute()

        if (count % 50_000L == 0L) {
            db.setTransactionSuccessful()
            db.endTransaction()
            db.beginTransaction()
        }
        if ((count and 0x3FFL) == 0L) {
            prog.rows = count
            val t = prog.total
            val pct = if (t > 0 && prog.phase == 2) ((prog.done * 100) / t).toInt().coerceIn(0, 100) else -1
            note(pct)
        }
    }

    fun finish() {
        rec.flush()
        rec.close()
        offs.flush()
        offs.close()
        db.setTransactionSuccessful()
        db.endTransaction()
        inTx = false
        ins.close()
        db.close()
        prog.rows = count
        meta.rows = count
        meta.tables = tables
        meta.state = "ready"
        meta.error = ""
        Datasets.write(dir, meta)
    }

    fun abort() {
        try {
            rec.close()
        } catch (e: Exception) {
        }
        try {
            offs.close()
        } catch (e: Exception) {
        }
        try {
            if (inTx) db.endTransaction()
        } catch (e: Exception) {
        }
        try {
            ins.close()
        } catch (e: Exception) {
        }
        try {
            db.close()
        } catch (e: Exception) {
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Reading: instant index search + optional deep scan of all the text
// ---------------------------------------------------------------------------------------------

class Dataset private constructor(
    val meta: Meta,
    private val db: SQLiteDatabase,
    private val rec: RandomAccessFile,
    private val offs: RandomAccessFile,
    private val recPath: String,
    private val colWord: String
) {
    companion object {
        fun open(ctx: Context, meta: Meta): Dataset {
            val d = Datasets.dir(ctx, meta.id)
            val db = SQLiteDatabase.openDatabase(File(d, "index.db").path, null, SQLiteDatabase.OPEN_READONLY)
            val rec = RandomAccessFile(File(d, "records.bin"), "r")
            val offs = RandomAccessFile(File(d, "offs.bin"), "r")
            return Dataset(meta, db, rec, offs, File(d, "records.bin").path, ctx.getString(R.string.col))
        }
    }

    fun close() {
        try {
            db.close()
        } catch (e: Exception) {
        }
        try {
            rec.close()
        } catch (e: Exception) {
        }
        try {
            offs.close()
        } catch (e: Exception) {
        }
    }

    private fun offsetOf(id: Long): Long {
        offs.seek((id - 1) * 8)
        val b = ByteArray(8)
        offs.readFully(b)
        var v = 0L
        for (i in 0 until 8) v = (v shl 8) or (b[i].toLong() and 0xFFL)
        return v
    }

    private fun readAt(off: Long): ByteArray? {
        rec.seek(off)
        var len = 0
        var shift = 0
        while (true) {
            val b = rec.read()
            if (b < 0) return null
            len = len or ((b and 0x7F) shl shift)
            if ((b and 0x80) == 0) break
            shift += 7
            if (shift > 28) return null
        }
        val buf = ByteArray(len)
        rec.readFully(buf)
        return buf
    }

    private fun bodyOf(text: String): String {
        val p = text.indexOf('\u001E')
        return if (p >= 0) text.substring(p + 1) else text
    }

    private fun rowOf(text: String): Row {
        val p = text.indexOf('\u001E')
        val tid = if (p > 0) (text.substring(0, p).toIntOrNull() ?: 0) else 0
        val t = if (tid >= 0 && tid < meta.tables.size) meta.tables[tid] else null
        val parts = bodyOf(text).split('\u001F')
        val f = ArrayList<Pair<String, String>>()
        for (i in parts.indices) {
            val v = parts[i].trim()
            if (v.isEmpty()) continue
            val h = if (t != null && i < t.headers.size) t.headers[i].trim() else ""
            f.add((if (h.isEmpty()) "$colWord ${i + 1}" else h) to v)
        }
        return Row(meta.name, t?.name ?: "", f)
    }

    /** Fast search through the full-text index; every result is checked against the real record text. */
    fun indexSearch(q: Query, limit: Int, cancel: AtomicBoolean): List<Row> {
        val ids = TreeSet<Long>()
        val per = limit * 3 + 100
        for (fq in q.ftsQueries()) {
            if (cancel.get()) break
            val c = db.rawQuery("SELECT docid FROM fts WHERE fts MATCH ? LIMIT $per", arrayOf(fq))
            try {
                while (c.moveToNext()) ids.add(c.getLong(0))
            } finally {
                c.close()
            }
        }
        val out = ArrayList<Row>()
        for (id in ids) {
            if (cancel.get() || out.size >= limit) break
            val buf = readAt(offsetOf(id)) ?: continue
            val text = String(buf, Charsets.UTF_8)
            if (!q.matches(Norm.text(bodyOf(text)))) continue
            out.add(rowOf(text))
        }
        return out
    }

    /** Slow but complete: reads every record and looks for the typed words anywhere inside the text. */
    fun deepSearch(q: Query, limit: Int, cancel: AtomicBoolean, sink: Sink): Int {
        val total = File(recPath).length()
        var found = 0
        var scanned = 0L
        var pos = 0L
        var tick = 0L
        val ins = BufferedInputStream(FileInputStream(recPath), 1 shl 20)
        try {
            var buf = ByteArray(8192)
            while (!cancel.get() && found < limit) {
                var len = 0
                var shift = 0
                var eof = false
                while (true) {
                    val b = ins.read()
                    if (b < 0) {
                        eof = true
                        break
                    }
                    pos++
                    len = len or ((b and 0x7F) shl shift)
                    if ((b and 0x80) == 0) break
                    shift += 7
                }
                if (eof) break
                if (buf.size < len) buf = ByteArray(maxOf(len, buf.size * 2))
                var got = 0
                while (got < len) {
                    val r = ins.read(buf, got, len - got)
                    if (r < 0) break
                    got += r
                }
                if (got < len) break
                pos += len.toLong()
                scanned++
                val text = String(buf, 0, len, Charsets.UTF_8)
                if (q.matches(Norm.text(bodyOf(text)))) {
                    sink.onRow(rowOf(text))
                    found++
                }
                if ((scanned and 0x3FFL) == 0L) {
                    val now = SystemClock.uptimeMillis()
                    if (now - tick >= 250L) {
                        tick = now
                        sink.onProgress(scanned, if (total > 0) ((pos * 100) / total).toInt() else -1)
                    }
                }
            }
        } finally {
            ins.close()
        }
        return found
    }
}
