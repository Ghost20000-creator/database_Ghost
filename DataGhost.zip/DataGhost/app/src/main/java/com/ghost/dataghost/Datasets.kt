package com.ghost.dataghost

import android.content.Context
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.Arrays
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/*
 * Every imported file becomes a "dataset" folder inside the app's private storage:
 *
 *   meta.json     name, format, state, row count, column titles, field delimiter
 *   records.bin   every record, one after another:  [length][table number 0x1E the original line]
 *   offs.bin      8 bytes per record: where that record starts inside records.bin
 *   index.bin     sorted 8-byte entries  (hash of a word << 32 | record number)  = the inverted index
 *   dir.bin       where each of the 128 hash ranges starts inside index.bin
 *   stop.bin      hash ranges of words that are too common to be worth indexing
 *
 * Building is ONE pass over the file: records are written, and one (word, record) entry per distinct word
 * is appended to one of 128 temporary files chosen by the hash. Afterwards every temporary file is
 * sorted in memory and appended to index.bin. No database, no per-row overhead: this is what makes
 * millions of rows import in minutes.
 *
 * A search hashes the typed words, finds each word's entries with a binary search directly on index.bin,
 * intersects the record numbers and reads only those records. Everything it shows is re-checked against
 * the real record text.
 */

/** Version of the stored format. Datasets built by an older version must be imported again. */
const val INDEX_VERSION = 3

private const val PARTS = 128
private const val STOP = 1_500_000
private const val LIST_CAP = 6_000_000
private const val MAX_VERIFY = 300_000

class TableInfo(val name: String, val headers: List<String>)

class Meta(
    val id: String,
    var name: String,
    var origin: String,
    var stamp: Long,
    var fmt: String,
    var state: String,
    var rows: Long,
    var error: String,
    var created: Long,
    var tables: List<TableInfo>,
    var delim: String,
    var ver: Int
)

object Datasets {
    fun root(ctx: Context): File = File(ctx.filesDir, "datasets")

    fun dir(ctx: Context, id: String): File = File(root(ctx), id)

    fun create(ctx: Context, m: Meta) {
        val d = dir(ctx, m.id)
        d.mkdirs()
        write(d, m)
    }

    fun write(dir: File, m: Meta) {
        val tables = JSONArray()
        for (t in m.tables) {
            tables.put(JSONObject().put("n", t.name).put("h", JSONArray(t.headers)))
        }
        val o = JSONObject()
        o.put("id", m.id)
        o.put("name", m.name)
        o.put("origin", m.origin)
        o.put("stamp", m.stamp)
        o.put("fmt", m.fmt)
        o.put("state", m.state)
        o.put("rows", m.rows)
        o.put("error", m.error)
        o.put("created", m.created)
        o.put("tables", tables)
        o.put("delim", m.delim)
        o.put("ver", m.ver)
        val tmp = File(dir, "meta.json.tmp")
        tmp.writeText(o.toString())
        tmp.renameTo(File(dir, "meta.json"))
    }

    fun read(dir: File): Meta? {
        return try {
            val o = JSONObject(File(dir, "meta.json").readText())
            val ts = ArrayList<TableInfo>()
            val ja = o.optJSONArray("tables")
            if (ja != null) {
                for (i in 0 until ja.length()) {
                    val to = ja.getJSONObject(i)
                    val ha = to.getJSONArray("h")
                    val hs = ArrayList<String>()
                    for (k in 0 until ha.length()) hs.add(ha.getString(k))
                    ts.add(TableInfo(to.getString("n"), hs))
                }
            }
            Meta(
                o.getString("id"), o.getString("name"), o.getString("origin"), o.optLong("stamp"),
                o.optString("fmt"), o.getString("state"), o.optLong("rows"), o.optString("error"),
                o.optLong("created"), ts, o.optString("delim"), o.optInt("ver", 0)
            )
        } catch (e: Exception) {
            null
        }
    }

    fun list(ctx: Context): List<Meta> {
        val out = ArrayList<Meta>()
        val dirs = root(ctx).listFiles() ?: return out
        for (d in dirs) {
            if (!d.isDirectory) continue
            val m = read(d)
            if (m != null) out.add(m)
        }
        out.sortBy { it.name.lowercase() }
        return out
    }

    fun delete(ctx: Context, id: String) {
        dir(ctx, id).deleteRecursively()
    }

    /** Removes the big files of a dataset (after a failed or cancelled import); meta.json stays. */
    fun wipe(dir: File) {
        for (n in arrayOf("records.bin", "offs.bin", "index.bin", "dir.bin", "stop.bin", "index.db")) {
            File(dir, n).delete()
        }
        File(dir, "tmp").deleteRecursively()
    }

    fun diskSize(ctx: Context, id: String): Long {
        val d = dir(ctx, id)
        var s = 0L
        for (n in arrayOf("records.bin", "offs.bin", "index.bin", "index.db")) s += File(d, n).length()
        return s
    }
}

// ---------------------------------------------------------------------------------------------
// Building: records + index in one pass while the file is read
// ---------------------------------------------------------------------------------------------

class DatasetBuilder(
    ctx: Context,
    private val meta: Meta,
    private val prog: Importer.Prog,
    private val note: (Int) -> Unit
) : RecordSink {
    private val dir = Datasets.dir(ctx, meta.id)
    private val tmpDir = File(dir, "tmp")
    private val rec = BufferedOutputStream(FileOutputStream(File(dir, "records.bin")), 1 shl 20)
    private val offs = BufferedOutputStream(FileOutputStream(File(dir, "offs.bin")), 1 shl 18)
    private val tables = ArrayList<TableInfo>()
    private var cur = 0
    private var prefix = ByteArray(0)
    private var delim = '\u001F'
    private var pos = 0L
    private var count = 0L
    private val offBuf = ByteArray(8)
    private val sb = StringBuilder()
    private val hbuf = IntArray(256)

    // how many entries every group of 512 hash values received (words that are too common are dropped)
    private val cnt = IntArray(1 shl 22)
    private val bufs = Array(PARTS) { ByteBuffer.allocate(32768) }
    private val chans = arrayOfNulls<FileChannel>(PARTS)

    init {
        tmpDir.mkdirs()
    }

    override fun delimiter(d: Char) {
        delim = d
    }

    override fun table(name: String, headers: List<String>) {
        tables.add(TableInfo(name, ArrayList(headers)))
        cur = tables.size - 1
        prefix = (cur.toString() + "\u001E").toByteArray(Charsets.UTF_8)
    }

    override fun cancelled(): Boolean = prog.cancel

    override fun bytes(n: Long) {
        prog.done = n
    }

    override fun line(text: String) {
        if (tables.isEmpty()) table("", emptyList())
        add(text)
    }

    override fun record(fields: List<String>) {
        var lastNon = -1
        for (i in fields.indices) {
            if (fields[i].isNotBlank()) lastNon = i
        }
        if (lastNon < 0) return
        if (tables.isEmpty()) table("", emptyList())
        sb.setLength(0)
        for (i in 0..lastNon) {
            if (i > 0) sb.append('\u001F')
            var f = fields[i].trim()
            if (f.indexOf('\u001F') >= 0 || f.indexOf('\u001E') >= 0) {
                f = f.replace('\u001F', ' ').replace('\u001E', ' ')
            }
            sb.append(f)
        }
        add(sb.toString())
    }

    /** Stores one record and registers its words. */
    private fun add(text: String) {
        val lb = text.toByteArray(Charsets.UTF_8)
        val total = prefix.size + lb.size

        // where this record starts
        var v = pos
        for (k in 7 downTo 0) {
            offBuf[k] = (v and 0xFFL).toByte()
            v = v ushr 8
        }
        offs.write(offBuf)

        // the record: length (varint), table number, the line
        var len = total
        var written = 0
        while (len >= 0x80) {
            rec.write((len and 0x7F) or 0x80)
            len = len ushr 7
            written++
        }
        rec.write(len)
        written++
        rec.write(prefix)
        rec.write(lb)
        pos += (written + total).toLong()
        count++

        // its words
        val n = Tok.hashes(Norm.text(text), hbuf, true)
        for (i in 0 until n) post(hbuf[i], count)

        if ((count and 0x3FFL) == 0L) {
            prog.rows = count
            val t = prog.total
            val pct = if (t > 0L && prog.phase == 2) ((prog.done * 100) / t).toInt().coerceIn(0, 100) else -1
            note(pct)
        }
    }

    private fun post(h: Int, id: Long) {
        val b = h ushr 9
        val c = cnt[b]
        if (c > STOP) return
        if (c == STOP) {
            cnt[b] = STOP + 1
            return
        }
        cnt[b] = c + 1
        val p = h ushr 24
        val bb = bufs[p]
        bb.putLong((h.toLong() shl 32) or id)
        if (!bb.hasRemaining()) flushPart(p)
    }

    private fun flushPart(p: Int) {
        val bb = bufs[p]
        if (bb.position() == 0) return
        var ch: FileChannel? = chans[p]
        if (ch == null) {
            val nc: FileChannel = FileOutputStream(File(tmpDir, "p$p")).channel
            chans[p] = nc
            ch = nc
        }
        bb.flip()
        while (bb.hasRemaining()) ch.write(bb)
        bb.clear()
    }

    private fun readLongs(f: File, arr: LongArray, n: Int, chunk: ByteArray) {
        val ins = FileInputStream(f)
        try {
            var filled = 0
            while (filled < n) {
                val want = minOf(chunk.size / 8, n - filled) * 8
                var got = 0
                while (got < want) {
                    val r = ins.read(chunk, got, want - got)
                    if (r < 0) throw EOFException()
                    got += r
                }
                ByteBuffer.wrap(chunk, 0, want).asLongBuffer().get(arr, filled, want / 8)
                filled += want / 8
            }
        } finally {
            ins.close()
        }
    }

    /** Second phase: sorts every temporary file and writes the final index. */
    fun finish() {
        prog.phase = 3
        note(-1)
        rec.flush()
        rec.close()
        offs.flush()
        offs.close()
        for (p in 0 until PARTS) flushPart(p)
        for (p in 0 until PARTS) {
            val c = chans[p]
            if (c != null) c.close()
        }

        val stop = ArrayList<Int>()
        for (b in cnt.indices) {
            if (cnt[b] > STOP) stop.add(b)
        }

        val dirArr = LongArray(PARTS + 1)
        val chunk = ByteArray(1 shl 20)
        val out = BufferedOutputStream(FileOutputStream(File(dir, "index.bin")), 1 shl 20)
        var total = 0L
        try {
            for (p in 0 until PARTS) {
                dirArr[p] = total
                val f = File(tmpDir, "p$p")
                if (!f.exists()) continue
                val n = (f.length() / 8).toInt()
                if (n > 0) {
                    val arr = LongArray(n)
                    readLongs(f, arr, n, chunk)
                    var m = 0
                    for (j in 0 until n) {
                        val x = arr[j]
                        val h = (x ushr 32).toInt()
                        if (cnt[h ushr 9] > STOP) continue
                        arr[m] = x
                        m++
                    }
                    Arrays.sort(arr, 0, m)
                    var w = 0
                    while (w < m) {
                        val k = minOf(chunk.size / 8, m - w)
                        ByteBuffer.wrap(chunk, 0, k * 8).asLongBuffer().put(arr, w, k)
                        out.write(chunk, 0, k * 8)
                        w += k
                    }
                    total += m.toLong()
                }
                f.delete()
            }
            dirArr[PARTS] = total
        } finally {
            out.close()
        }

        val dout = DataOutputStream(BufferedOutputStream(FileOutputStream(File(dir, "dir.bin"))))
        try {
            for (x in dirArr) dout.writeLong(x)
        } finally {
            dout.close()
        }
        val sout = DataOutputStream(BufferedOutputStream(FileOutputStream(File(dir, "stop.bin"))))
        try {
            sout.writeInt(stop.size)
            for (x in stop) sout.writeInt(x)
        } finally {
            sout.close()
        }
        tmpDir.deleteRecursively()

        prog.rows = count
        meta.rows = count
        meta.tables = tables
        meta.delim = delim.toString()
        meta.ver = INDEX_VERSION
        meta.state = "ready"
        meta.error = ""
        Datasets.write(dir, meta)
    }

    fun abort() {
        try {
            rec.close()
        } catch (e: Exception) {
        }
        try {
            offs.close()
        } catch (e: Exception) {
        }
        for (p in 0 until PARTS) {
            try {
                chans[p]?.close()
            } catch (e: Exception) {
            }
        }
        tmpDir.deleteRecursively()
    }
}

// ---------------------------------------------------------------------------------------------
// Reading: instant index search + parallel deep scan
// ---------------------------------------------------------------------------------------------

class IndexResult(val rows: List<Row>, val partial: Boolean)

class Dataset private constructor(
    val meta: Meta,
    private val rec: RandomAccessFile,
    private val offs: RandomAccessFile,
    private val idx: RandomAccessFile,
    private val dirArr: LongArray,
    private val stop: IntArray,
    private val recPath: String,
    private val offsPath: String,
    private val colWord: String
) {
    private val delimChar: Char = if (meta.delim.isNotEmpty()) meta.delim[0] else '\u001F'
    private val eight = ByteArray(8)

    companion object {
        fun open(ctx: Context, meta: Meta): Dataset {
            val d = Datasets.dir(ctx, meta.id)
            val dirArr = LongArray(PARTS + 1)
            val din = DataInputStream(BufferedInputStream(FileInputStream(File(d, "dir.bin"))))
            try {
                for (i in dirArr.indices) dirArr[i] = din.readLong()
            } finally {
                din.close()
            }
            var stop = IntArray(0)
            val sin = DataInputStream(BufferedInputStream(FileInputStream(File(d, "stop.bin"))))
            try {
                val n = sin.readInt()
                val arr = IntArray(n)
                for (i in 0 until n) arr[i] = sin.readInt()
                stop = arr
            } finally {
                sin.close()
            }
            val recFile = File(d, "records.bin")
            val offsFile = File(d, "offs.bin")
            return Dataset(
                meta,
                RandomAccessFile(recFile, "r"),
                RandomAccessFile(offsFile, "r"),
                RandomAccessFile(File(d, "index.bin"), "r"),
                dirArr, stop, recFile.path, offsFile.path, ctx.getString(R.string.col)
            )
        }
    }

    fun close() {
        try {
            rec.close()
        } catch (e: Exception) {
        }
        try {
            offs.close()
        } catch (e: Exception) {
        }
        try {
            idx.close()
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------ records

    private fun offsetOf(id: Long): Long {
        offs.seek((id - 1) * 8)
        offs.readFully(eight)
        var v = 0L
        for (i in 0 until 8) v = (v shl 8) or (eight[i].toLong() and 0xFFL)
        return v
    }

    private fun readAt(off: Long): ByteArray? {
        rec.seek(off)
        var len = 0
        var shift = 0
        while (true) {
            val b = rec.read()
            if (b < 0) return null
            len = len or ((b and 0x7F) shl shift)
            if ((b and 0x80) == 0) break
            shift += 7
            if (shift > 28) return null
        }
        val buf = ByteArray(len)
        rec.readFully(buf)
        return buf
    }

    private fun bodyOf(text: String): String {
        val p = text.indexOf('\u001E')
        return if (p >= 0) text.substring(p + 1) else text
    }

    private fun rowOf(text: String): Row {
        val p = text.indexOf('\u001E')
        val tid = if (p > 0) (text.substring(0, p).toIntOrNull() ?: 0) else 0
        val t = if (tid >= 0 && tid < meta.tables.size) meta.tables[tid] else null
        val parts = Csv.split(bodyOf(text), delimChar)
        val f = ArrayList<Pair<String, String>>()
        for (i in parts.indices) {
            val v = parts[i].trim()
            if (v.isEmpty()) continue
            val h = if (t != null && i < t.headers.size) t.headers[i].trim() else ""
            f.add((if (h.isEmpty()) "$colWord ${i + 1}" else h) to v)
        }
        return Row(meta.name, t?.name ?: "", f)
    }

    // ------------------------------------------------------------ index lookup

    private fun keyAt(i: Long): Long {
        idx.seek(i * 8)
        idx.readFully(eight)
        var v = 0L
        for (k in 0 until 8) v = (v shl 8) or (eight[k].toLong() and 0xFFL)
        return v
    }

    /** First entry in [lo0, hi0) whose key is >= key. */
    private fun lowerBound(key: Long, lo0: Long, hi0: Long): Long {
        var lo = lo0
        var hi = hi0
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (keyAt(mid) < key) lo = mid + 1 else hi = mid
        }
        return lo
    }

    private fun isStopped(h: Int): Boolean = Arrays.binarySearch(stop, h ushr 9) >= 0

    /** Record numbers (ascending) of every record that contains the word with hash [h]; null when the word is too common. */
    private fun postings(h: Int): IntArray? {
        val p = h ushr 24
        val lo = dirArr[p]
        val hi = dirArr[p + 1]
        if (lo >= hi) return IntArray(0)
        val a = lowerBound(h.toLong() shl 32, lo, hi)
        val upper = if (h == Int.MAX_VALUE) Long.MAX_VALUE else (h.toLong() + 1) shl 32
        val b = lowerBound(upper, a, hi)
        val cntL = b - a
        if (cntL > LIST_CAP) return null
        val n = cntL.toInt()
        val out = IntArray(n)
        if (n == 0) return out
        idx.seek(a * 8)
        val chunk = ByteArray(1 shl 16)
        var filled = 0
        while (filled < n) {
            val k = minOf(chunk.size / 8, n - filled)
            idx.readFully(chunk, 0, k * 8)
            var o = 0
            for (j in 0 until k) {
                out[filled + j] = ((chunk[o + 4].toInt() and 0xFF) shl 24) or
                    ((chunk[o + 5].toInt() and 0xFF) shl 16) or
                    ((chunk[o + 6].toInt() and 0xFF) shl 8) or
                    (chunk[o + 7].toInt() and 0xFF)
                o += 8
            }
            filled += k
        }
        return out
    }

    private fun intersect(a: IntArray, b: IntArray): IntArray {
        val small = if (a.size <= b.size) a else b
        val large = if (a.size <= b.size) b else a
        val out = IntArray(small.size)
        var n = 0
        if (small.size * 20L < large.size) {
            for (x in small) {
                if (Arrays.binarySearch(large, x) >= 0) {
                    out[n] = x
                    n++
                }
            }
        } else {
            var i = 0
            var j = 0
            while (i < small.size && j < large.size) {
                val x = small[i]
                val y = large[j]
                if (x == y) {
                    out[n] = x
                    n++
                    i++
                    j++
                } else if (x < y) {
                    i++
                } else {
                    j++
                }
            }
        }
        return out.copyOf(n)
    }

    private fun union(a: IntArray, b: IntArray): IntArray {
        if (a.isEmpty()) return b
        if (b.isEmpty()) return a
        val out = IntArray(a.size + b.size)
        var i = 0
        var j = 0
        var n = 0
        while (i < a.size || j < b.size) {
            val x = if (i < a.size) a[i] else Int.MAX_VALUE
            val y = if (j < b.size) b[j] else Int.MAX_VALUE
            if (x == y) {
                out[n] = x
                n++
                i++
                j++
            } else if (x < y) {
                out[n] = x
                n++
                i++
            } else {
                out[n] = y
                n++
                j++
            }
        }
        return out.copyOf(n)
    }

    /**
     * Instant search through the index: finds the records that contain every typed word as a whole word.
     * Returns null when the index cannot help (every typed word is too common or too short).
     */
    fun indexSearch(q: Query, limit: Int, cancel: AtomicBoolean): IndexResult? {
        val lists = ArrayList<IntArray>()
        val hb = IntArray(64)
        for (w in q.words) {
            if (cancel.get()) return IndexResult(emptyList(), false)
            var wordList = IntArray(0)
            var usable = true
            for (v in w) {
                val n = Tok.hashes(v, hb, false)
                var vList: IntArray? = null
                for (k in 0 until n) {
                    val h = hb[k]
                    if (isStopped(h)) continue
                    val pl = postings(h) ?: continue
                    val prev = vList
                    vList = if (prev == null) pl else intersect(prev, pl)
                    if (vList.isEmpty()) break
                }
                if (vList == null) {
                    usable = false
                    break
                }
                wordList = union(wordList, vList)
            }
            if (usable) lists.add(wordList)
        }
        if (lists.isEmpty()) return null

        lists.sortBy { it.size }
        var cand = lists[0]
        for (i in 1 until lists.size) {
            if (cand.isEmpty()) break
            cand = intersect(cand, lists[i])
        }

        // every candidate is checked against the real text of the record
        val out = ArrayList<Row>()
        var examined = 0
        var partial = false
        val t0 = SystemClock.elapsedRealtime()
        for (id in cand) {
            if (cancel.get() || out.size >= limit) break
            if (examined >= MAX_VERIFY ||
                ((examined and 255) == 0 && SystemClock.elapsedRealtime() - t0 > 4000L)
            ) {
                partial = true
                break
            }
            examined++
            val buf = readAt(offsetOf(id.toLong())) ?: continue
            val text = String(buf, Charsets.UTF_8)
            if (!q.matches(Norm.text(bodyOf(text)))) continue
            out.add(rowOf(text))
        }
        return IndexResult(out, partial && out.size < limit)
    }

    // ------------------------------------------------------------ deep scan

    /**
     * Complete but slower: reads every record (all processor cores at once) and looks for the typed words
     * anywhere inside the text, also in the middle of a word.
     */
    fun deepSearch(q: Query, limit: Int, cancel: AtomicBoolean, sink: Sink): Int {
        val n = meta.rows
        if (n <= 0L) return 0
        val cpu = Runtime.getRuntime().availableProcessors()
        val threads = if (n < 20_000L) 1 else maxOf(1, minOf(cpu, 6))
        val found = AtomicInteger(0)
        val scanned = AtomicLong(0)
        val results = ArrayList<Pair<Long, Row>>()
        val error = AtomicReference<Throwable>()
        val pool = Executors.newFixedThreadPool(threads)
        val per = (n + threads - 1) / threads
        for (c in 0 until threads) {
            val from = c * per + 1
            val to = minOf(n, (c + 1) * per)
            if (from > to) continue
            pool.execute {
                try {
                    scanRange(from, to, q, limit, cancel, found, scanned, results)
                } catch (t: Throwable) {
                    error.compareAndSet(null, t)
                }
            }
        }
        pool.shutdown()
        while (!pool.awaitTermination(250L, TimeUnit.MILLISECONDS)) {
            val s = scanned.get()
            sink.onProgress(s, ((s * 100) / n).toInt().coerceIn(0, 100))
        }
        val err = error.get()
        if (err != null) throw err
        val sorted = synchronized(results) { results.sortedBy { it.first } }
        var k = 0
        for (p in sorted) {
            if (k >= limit) break
            sink.onRow(p.second)
            k++
        }
        return k
    }

    private fun scanRange(
        from: Long,
        to: Long,
        q: Query,
        limit: Int,
        cancel: AtomicBoolean,
        found: AtomicInteger,
        scanned: AtomicLong,
        results: MutableList<Pair<Long, Row>>
    ) {
        var start = 0L
        val of = RandomAccessFile(offsPath, "r")
        try {
            of.seek((from - 1) * 8)
            val b = ByteArray(8)
            of.readFully(b)
            var v = 0L
            for (i in 0 until 8) v = (v shl 8) or (b[i].toLong() and 0xFFL)
            start = v
        } finally {
            of.close()
        }
        val fis = FileInputStream(recPath)
        try {
            fis.channel.position(start)
            val ins = BufferedInputStream(fis, 1 shl 20)
            var buf = ByteArray(8192)
            var id = from
            var local = 0
            while (id <= to) {
                if (cancel.get() || found.get() >= limit) break
                var len = 0
                var shift = 0
                var eof = false
                while (true) {
                    val b = ins.read()
                    if (b < 0) {
                        eof = true
                        break
                    }
                    len = len or ((b and 0x7F) shl shift)
                    if ((b and 0x80) == 0) break
                    shift += 7
                }
                if (eof) break
                if (buf.size < len) buf = ByteArray(maxOf(len, buf.size * 2))
                var got = 0
                while (got < len) {
                    val r = ins.read(buf, got, len - got)
                    if (r < 0) break
                    got += r
                }
                if (got < len) break
                val text = String(buf, 0, len, Charsets.UTF_8)
                if (q.matches(Norm.text(bodyOf(text)))) {
                    val row = rowOf(text)
                    synchronized(results) {
                        results.add(Pair(id, row))
                    }
                    found.incrementAndGet()
                }
                id++
                local++
                if (local == 2048) {
                    scanned.addAndGet(local.toLong())
                    local = 0
                }
            }
            scanned.addAndGet(local.toLong())
        } finally {
            fis.close()
        }
    }
}
