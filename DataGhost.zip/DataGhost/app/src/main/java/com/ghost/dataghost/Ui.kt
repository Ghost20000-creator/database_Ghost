package com.ghost.dataghost

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

object Ui {
    val BG = Color.BLACK
    val SURFACE = Color.parseColor("#1C1C1E")
    val SURFACE2 = Color.parseColor("#2C2C2E")
    val STROKE = Color.parseColor("#3A3A3C")
    val TEXT = Color.parseColor("#F2F2F2")
    val MUTED = Color.parseColor("#9A9AA0")
    val GREEN = Color.parseColor("#2ECC71")
    val RED = Color.parseColor("#E53935")
    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.lp(topDp: Int = 0, w: Int = Ui.MATCH, h: Int = Ui.WRAP): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h)
    p.topMargin = dp(topDp)
    return p
}

fun Context.rounded(fill: Int, radiusDp: Int = 14, stroke: Int = 0, strokeDp: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(fill)
    g.cornerRadius = dp(radiusDp).toFloat()
    if (strokeDp > 0) g.setStroke(dp(strokeDp), stroke)
    return g
}

fun Context.pressable(base: GradientDrawable): RippleDrawable =
    RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), base, null)

fun Context.label(t: CharSequence, sp: Float = 15f, color: Int = Ui.TEXT, bold: Boolean = false): TextView {
    val v = TextView(this)
    v.text = t
    v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    v.setTextColor(color)
    if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
    return v
}

fun Context.button(
    t: CharSequence,
    fill: Int,
    textColor: Int = Color.BLACK,
    sp: Float = 16f,
    padV: Int = 14,
    padH: Int = 18
): TextView {
    val v = label(t, sp, textColor, true)
    v.gravity = Gravity.CENTER
    v.setPadding(dp(padH), dp(padV), dp(padH), dp(padV))
    v.background = pressable(rounded(fill, 14))
    v.isClickable = true
    v.isFocusable = true
    return v
}

fun Context.chip(t: CharSequence, color: Int): TextView {
    val v = label(t, 11f, color, true)
    v.setPadding(dp(8), dp(2), dp(8), dp(2))
    v.background = rounded(Color.TRANSPARENT, 8, color, 1)
    return v
}

fun Context.card(): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.setPadding(dp(14), dp(12), dp(14), dp(12))
    c.background = rounded(Ui.SURFACE, 16, Ui.STROKE, 1)
    return c
}

fun Context.header(title: CharSequence, extra: View? = null, onBack: () -> Unit): LinearLayout {
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    val rtl = resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL
    val back = label(if (rtl) "\u2192" else "\u2190", 26f, Ui.GREEN, true)
    back.setPadding(dp(10), dp(6), dp(14), dp(6))
    back.setOnClickListener { onBack() }
    row.addView(back)
    val tv = label(title, 18f, Ui.TEXT, true)
    tv.maxLines = 1
    tv.ellipsize = TextUtils.TruncateAt.END
    row.addView(tv, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
    if (extra != null) row.addView(extra)
    return row
}

fun Context.copyText(t: String) {
    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Data Ghost", t.take(500_000)))
    Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show()
}

fun Activity.hideKeyboard() {
    val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    val tok = currentFocus?.windowToken ?: window.decorView.windowToken
    imm.hideSoftInputFromWindow(tok, 0)
}

fun readableSize(b: Long): String {
    if (b < 1024L) return "$b B"
    val kb = b / 1024.0
    if (kb < 1024.0) return String.format(Locale.US, "%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024.0) return String.format(Locale.US, "%.1f MB", mb)
    return String.format(Locale.US, "%.2f GB", mb / 1024.0)
}

/** Builds the detailed text of one result: muted field name, then the value with matches highlighted. */
fun recordText(r: Row, terms: List<String>): CharSequence {
    val sb = SpannableStringBuilder()
    var first = true
    for ((k, v) in r.fields) {
        if (!first) sb.append("\n\n")
        first = false
        val a = sb.length
        sb.append(k)
        sb.setSpan(ForegroundColorSpan(Ui.MUTED), a, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(RelativeSizeSpan(0.8f), a, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.append('\n')
        val s = sb.length
        sb.append(v)
        mark(sb, s, v, terms)
    }
    return sb
}

private fun mark(sb: SpannableStringBuilder, base: Int, v: String, terms: List<String>) {
    if (terms.isEmpty()) return
    val low = v.lowercase()
    if (low.length != v.length) return
    var n = 0
    for (h in terms) {
        if (h.isEmpty()) continue
        var i = low.indexOf(h)
        while (i >= 0 && n < 12) {
            sb.setSpan(
                ForegroundColorSpan(Ui.GREEN), base + i, base + i + h.length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            sb.setSpan(
                StyleSpan(Typeface.BOLD), base + i, base + i + h.length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            n++
            i = low.indexOf(h, i + h.length)
        }
    }
}
