package com.ghost.dataghost

object Config {
    // The channel the user is sent to when pressing Subscribe
    const val CHANNEL_URL = "https://t.me/GhostOfficial_new"

    // true  = the subscribe prompt appears every time the app is opened
    // false = it appears until the user taps Subscribe once
    const val GATE_EVERY_LAUNCH = true

    // Maximum number of results shown for one search
    const val MAX_RESULTS = 500
}
