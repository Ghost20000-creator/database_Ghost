package com.ghost.dataghost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock

class ImportService : Service() {
    private var lastNotify = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel(CHANNEL, getString(R.string.imp_channel), NotificationManager.IMPORTANCE_LOW)
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = buildNotification(getString(R.string.imp_working), -1)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, n)
        }
        var start = false
        synchronized(Importer) {
            Importer.latestStart = startId
            if (!Importer.workerRunning) {
                Importer.workerRunning = true
                start = true
            }
        }
        if (start) Thread { work() }.start()
        return START_NOT_STICKY
    }

    private fun work() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DataGhost:import")
        lock.acquire(6 * 60 * 60 * 1000L)
        var stopId = -1
        try {
            stopId = Importer.workerLoop(applicationContext) { name, pct -> progressNote(name, pct) }
        } catch (e: Throwable) {
            synchronized(Importer) {
                Importer.workerRunning = false
            }
        } finally {
            try {
                if (lock.isHeld) lock.release()
            } catch (e: Exception) {
            }
        }
        if (stopId >= 0) stopSelf(stopId) else stopSelf()
    }

    private fun progressNote(name: String, pct: Int) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastNotify < 1000L) return
        lastNotify = now
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(getString(R.string.imp_notif_text, name), pct))
    }

    private fun buildNotification(text: String, pct: Int): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, FilesActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
        if (pct >= 0) b.setProgress(100, pct, false) else b.setProgress(0, 0, true)
        return b.build()
    }

    companion object {
        private const val CHANNEL = "import"
        private const val NOTIF_ID = 7
    }
}
