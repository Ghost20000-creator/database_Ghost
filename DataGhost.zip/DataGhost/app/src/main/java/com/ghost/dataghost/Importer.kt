package com.ghost.dataghost

import android.content.Context
import android.content.Intent
import android.content.res.AssetManager
import android.net.Uri
import android.os.StatFs
import android.os.SystemClock
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue

typealias Notifier = (String, Int) -> Unit

class CancelledException : RuntimeException()

/** Queue of files waiting to be imported (read and indexed). Shared by the screens and the background service. */
object Importer {
    class Task(
        val id: String,
        val name: String,
        val origin: String,
        val stamp: Long,
        val uri: String?,
        val assetPath: String?,
        val size: Long
    )

    /** Live progress of one import; the files screen reads it every fraction of a second. */
    class Prog {
        // 0 waiting, 1 copying the file, 2 reading and indexing
        @Volatile
        var phase = 0

        @Volatile
        var done = 0L

        @Volatile
        var total = 0L

        @Volatile
        var rows = 0L

        @Volatile
        var cancel = false
    }

    val queue = LinkedBlockingQueue<Task>()
    val progress = ConcurrentHashMap<String, Prog>()

    @Volatile
    var workerRunning = false

    @Volatile
    var latestStart = 0

    private fun newId(): String = UUID.randomUUID().toString().substring(0, 8)

    fun activeIds(): Set<String> = HashSet(progress.keys)

    /** A file the user picked from the phone. */
    fun enqueueUser(ctx: Context, uri: Uri, name: String, size: Long) {
        add(ctx, Task(newId(), name, "user", 0L, uri.toString(), null, size))
    }

    /**
     * Files that were put inside the APK (assets) are imported automatically the first time the app runs,
     * and again whenever the APK is replaced by a new one.
     */
    private val syncLock = Any()

    fun syncAssets(ctx: Context) {
        synchronized(syncLock) {
            if (progress.isEmpty()) {
                File(ctx.filesDir, "tmp").deleteRecursively()
                File(ctx.filesDir, "cache_data").deleteRecursively()
            }
            val stamp = Library.apkStamp(ctx)
            val assets = Library.list(ctx)
            val existing = Datasets.list(ctx)
            val wanted = HashSet<String>()
            for (a in assets) {
                val origin = "asset:" + a.path
                wanted.add(origin)
                val ex = existing.firstOrNull { it.origin == origin }
                if (ex != null) {
                    val active = progress.containsKey(ex.id)
                    if (active || (ex.stamp == stamp && (ex.state == "ready" || ex.state == "error"))) continue
                    Datasets.delete(ctx, ex.id)
                }
                add(ctx, Task(newId(), a.name, origin, stamp, null, a.path, a.size))
            }
            for (ex in existing) {
                if (ex.origin.startsWith("asset:") && !wanted.contains(ex.origin) && !progress.containsKey(ex.id)) {
                    Datasets.delete(ctx, ex.id)
                }
            }
        }
    }

    /** Cancels an import that is waiting or running, or removes a finished dataset. */
    fun cancel(ctx: Context, id: String) {
        val p = progress[id]
        if (p != null) p.cancel = true
        val removed = queue.removeIf { it.id == id }
        if (removed || p == null) {
            Datasets.delete(ctx, id)
            progress.remove(id)
        }
    }

    private fun add(ctx: Context, t: Task) {
        val m = Meta(
            t.id, t.name, t.origin, t.stamp, "", "importing", 0L, "",
            System.currentTimeMillis(), emptyList()
        )
        Datasets.create(ctx, m)
        val p = Prog()
        p.total = t.size
        progress[t.id] = p
        queue.add(t)
        kick(ctx)
    }

    /** Starts the foreground service that runs the queue (so the import continues when the app is closed). */
    fun kick(ctx: Context) {
        val app = ctx.applicationContext
        try {
            app.startForegroundService(Intent(app, ImportService::class.java))
        } catch (e: Exception) {
            // the system refused the service: run the queue inside this process instead
            var start = false
            synchronized(this) {
                if (!workerRunning) {
                    workerRunning = true
                    start = true
                }
            }
            if (start) Thread { workerLoop(app, null) }.start()
        }
    }

    /** Runs queued imports one after another. Returns the start id the service may stop itself with. */
    fun workerLoop(ctx: Context, notifier: Notifier?): Int {
        var stopId = -1
        while (true) {
            var t: Task? = null
            synchronized(this) {
                t = queue.poll()
                if (t == null) {
                    workerRunning = false
                    stopId = latestStart
                }
            }
            val task = t ?: break
            process(ctx, task, notifier)
        }
        return stopId
    }

    private fun process(ctx: Context, t: Task, notifier: Notifier?) {
        val prog = progress[t.id] ?: Prog().also { progress[t.id] = it }
        val dir = Datasets.dir(ctx, t.id)
        val meta = Datasets.read(dir)
        if (meta == null) {
            progress.remove(t.id)
            return
        }
        var writer: DatasetWriter? = null
        var tmp: File? = null
        val note: (Int) -> Unit = { pct -> notifier?.invoke(t.name, pct) }
        try {
            if (prog.cancel) throw CancelledException()
            note(-1)
            val opener = openerFor(ctx, t)

            // what kind of file is it?
            val head = ByteArray(32)
            var n = 0
            val h = opener()
            try {
                while (n < head.size) {
                    val r = h.read(head, n, head.size - n)
                    if (r < 0) break
                    n += r
                }
            } finally {
                h.close()
            }
            val fmt = Library.sniff(head, n, t.name)
            meta.fmt = fmt.label
            Datasets.write(dir, meta)
            checkSpace(ctx, t.size, fmt)

            val w = DatasetWriter(ctx, meta, prog, note)
            writer = w
            if (fmt == Fmt.TEXT) {
                // text files are streamed: nothing is copied, nothing is kept in memory
                prog.phase = 2
                prog.done = 0
                TextParser.parse(opener, w)
            } else {
                // database / Excel files need a real file on disk
                val f = copyToTemp(ctx, opener, t, prog, note)
                tmp = f
                prog.phase = 2
                prog.done = 0
                prog.total = 0
                when (fmt) {
                    Fmt.SQLITE -> SqliteParser.parse(f, w)
                    Fmt.ACCESS -> AccessParser.parse(f, w)
                    Fmt.XLSX -> XlsxParser.parse(f, w)
                    Fmt.XLS -> XlsParser.parse(f, w)
                    else -> {
                    }
                }
            }
            if (prog.cancel) throw CancelledException()
            w.finish()
            writer = null
        } catch (e: CancelledException) {
            writer?.abort()
            Datasets.delete(ctx, t.id)
        } catch (e: Throwable) {
            writer?.abort()
            meta.state = "error"
            meta.error = e.message ?: e.javaClass.simpleName
            File(dir, "records.bin").delete()
            File(dir, "offs.bin").delete()
            File(dir, "index.db").delete()
            try {
                Datasets.write(dir, meta)
            } catch (x: Exception) {
            }
        } finally {
            tmp?.delete()
            progress.remove(t.id)
        }
    }

    private fun openerFor(ctx: Context, t: Task): () -> InputStream {
        val ap = t.assetPath
        if (ap != null) return { ctx.assets.open(ap, AssetManager.ACCESS_STREAMING) }
        val uri = Uri.parse(t.uri)
        return { ctx.contentResolver.openInputStream(uri) ?: throw IOException("cannot open the file") }
    }

    private fun copyToTemp(
        ctx: Context,
        opener: () -> InputStream,
        t: Task,
        prog: Prog,
        note: (Int) -> Unit
    ): File {
        val dir = File(ctx.filesDir, "tmp")
        dir.mkdirs()
        val f = File(dir, t.id + ".bin")
        prog.phase = 1
        prog.done = 0
        prog.total = t.size
        val ins = opener()
        try {
            FileOutputStream(f).use { out ->
                val buf = ByteArray(1 shl 16)
                var last = 0L
                while (true) {
                    if (prog.cancel) throw CancelledException()
                    val r = ins.read(buf)
                    if (r < 0) break
                    out.write(buf, 0, r)
                    prog.done += r.toLong()
                    val now = SystemClock.elapsedRealtime()
                    if (now - last >= 1000L) {
                        last = now
                        val tot = prog.total
                        note(if (tot > 0L) ((prog.done * 100) / tot).toInt().coerceIn(0, 100) else -1)
                    }
                }
            }
        } finally {
            ins.close()
        }
        return f
    }

    private fun checkSpace(ctx: Context, size: Long, fmt: Fmt) {
        if (size <= 0L) return
        val need = if (fmt == Fmt.TEXT) size * 2 else size * 3
        val free = StatFs(ctx.filesDir.path).availableBytes
        if (free < need) {
            throw IOException(ctx.getString(R.string.need_space, readableSize(need), readableSize(free)))
        }
    }
}
