package com.ghost.dataghost

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView

class FilesActivity : Activity() {
    private lateinit var box: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.setPadding(dp(16), dp(12), dp(16), dp(8))
        root.addView(header(getString(R.string.pick_file)) { finish() })

        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(box)
        root.addView(sv, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)

        box.addView(label(getString(R.string.preparing), 14f, Ui.MUTED), lp(16))

        Thread {
            val items = try {
                Library.list(this)
            } catch (e: Throwable) {
                emptyList<DataFile>()
            }
            runOnUiThread { show(items) }
        }.start()
    }

    private fun show(items: List<DataFile>) {
        box.removeAllViews()
        if (items.isEmpty()) {
            val t = label(getString(R.string.no_files), 15f, Ui.MUTED)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(8), dp(48), dp(8), dp(8))
            box.addView(t, lp())
            return
        }
        for (e in items) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(14), dp(14), dp(14), dp(14))
            row.background = pressable(rounded(Ui.SURFACE, 16, Ui.STROKE, 1))

            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.addView(label(e.name, 16f, Ui.TEXT, true))

            val meta = LinearLayout(this)
            meta.orientation = LinearLayout.HORIZONTAL
            meta.gravity = Gravity.CENTER_VERTICAL
            meta.addView(chip(e.fmt.label, Ui.GREEN))
            if (e.size >= 0) {
                val sz = label(readableSize(e.size), 12f, Ui.MUTED)
                sz.setPaddingRelative(dp(8), 0, 0, 0)
                meta.addView(sz)
            }
            col.addView(meta, lp(6))

            row.addView(col, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
            row.addView(label(if (isRtl()) "\u2039" else "\u203A", 28f, Ui.GREEN, true))

            row.setOnClickListener {
                startActivity(Intent(this, SearchActivity::class.java).putExtra("path", e.path))
            }
            box.addView(row, lp(10))
        }
    }

    private fun isRtl(): Boolean =
        resources.configuration.layoutDirection == android.view.View.LAYOUT_DIRECTION_RTL
}
