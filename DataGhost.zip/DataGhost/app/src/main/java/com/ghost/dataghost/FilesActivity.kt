package com.ghost.dataghost

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.NumberFormat

class FilesActivity : Activity() {
    private lateinit var box: LinearLayout
    private val ui = Handler(Looper.getMainLooper())
    private var lastActive: Set<String> = emptySet()
    private val statusViews = HashMap<String, TextView>()
    private val barViews = HashMap<String, ProgressBar>()

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            ui.postDelayed(this, 700L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.setPadding(dp(16), dp(12), dp(16), dp(8))

        val add = button(getString(R.string.btn_add), Ui.GREEN, Color.BLACK, 14f, 8, 14)
        add.setOnClickListener { openPicker() }
        root.addView(header(getString(R.string.my_files), add) { finish() })

        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(box)
        root.addView(sv, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 5)
        }
        if (intent.getBooleanExtra("pick", false)) openPicker()
    }

    override fun onResume() {
        super.onResume()
        reload()
        ui.postDelayed(ticker, 700L)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(ticker)
    }

    // ---------------------------------------------------------------- adding files

    private fun openPicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        try {
            startActivityForResult(i, REQ_PICK)
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "error", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        val cd = data.clipData
        if (cd != null) {
            for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri)
        } else {
            val one = data.data
            if (one != null) uris.add(one)
        }
        for (u in uris) {
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // not every provider allows it; reading right now still works
            }
            val info = describe(u)
            Importer.enqueueUser(this, u, info.first, info.second)
        }
        reload()
    }

    private fun describe(u: Uri): Pair<String, Long> {
        var name: String? = null
        var size = -1L
        try {
            val c = contentResolver.query(u, null, null, null, null)
            if (c != null) {
                try {
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (ni >= 0) name = c.getString(ni)
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                    }
                } finally {
                    c.close()
                }
            }
        } catch (e: Exception) {
            // keep the defaults
        }
        return Pair(name ?: (u.lastPathSegment ?: "file"), size)
    }

    // ---------------------------------------------------------------- list

    private fun reload() {
        lastActive = Importer.activeIds()
        render(Datasets.list(this))
    }

    /** Called every moment: refreshes the progress texts, or the whole list when something finished. */
    private fun tick() {
        val active = Importer.activeIds()
        if (active != lastActive) {
            reload()
            return
        }
        for ((id, tv) in statusViews) {
            val p = Importer.progress[id] ?: continue
            tv.text = statusText(p)
            val bar = barViews[id]
            if (bar != null) {
                val pc = pctOf(p)
                bar.isIndeterminate = pc < 0
                if (pc >= 0) bar.progress = pc
            }
        }
    }

    private fun render(metas: List<Meta>) {
        box.removeAllViews()
        statusViews.clear()
        barViews.clear()
        if (metas.isEmpty()) {
            val t = label(getString(R.string.no_files), 15f, Ui.MUTED)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(8), dp(48), dp(8), dp(8))
            box.addView(t, lp())
            return
        }
        for (m in metas) box.addView(cardFor(m), lp(10))
    }

    private fun cardFor(m: Meta): View {
        val prog = Importer.progress[m.id]
        val importing = m.state == "importing" && prog != null
        val failed = m.state == "error" || (m.state == "importing" && prog == null)
        val builtin = m.origin.startsWith("asset:")

        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(12), dp(14), dp(12))
        c.background = pressable(rounded(Ui.SURFACE, 16, Ui.STROKE, 1))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(label(m.name, 16f, Ui.TEXT, true), LinearLayout.LayoutParams(0, Ui.WRAP, 1f))

        if (importing) {
            val b = label(getString(R.string.cancel), 13f, Ui.RED, true)
            b.setPadding(dp(10), dp(6), dp(10), dp(6))
            b.setOnClickListener {
                Importer.cancel(this, m.id)
                reload()
            }
            top.addView(b)
        } else if (failed && builtin) {
            val b = label(getString(R.string.retry), 13f, Ui.GREEN, true)
            b.setPadding(dp(10), dp(6), dp(10), dp(6))
            b.setOnClickListener {
                Datasets.delete(this, m.id)
                Thread {
                    try {
                        Importer.syncAssets(applicationContext)
                    } catch (e: Throwable) {
                    }
                }.start()
                ui.postDelayed({ reload() }, 700L)
            }
            top.addView(b)
        } else if (!builtin) {
            val b = label(getString(R.string.delete), 13f, Ui.RED, true)
            b.setPadding(dp(10), dp(6), dp(10), dp(6))
            b.setOnClickListener { confirmDelete(m) }
            top.addView(b)
        }
        c.addView(top)

        if (importing && prog != null) {
            val st = label(statusText(prog), 13f, Ui.MUTED)
            statusViews[m.id] = st
            c.addView(st, lp(6))
            val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
            bar.max = 100
            bar.progressTintList = ColorStateList.valueOf(Ui.GREEN)
            bar.progressBackgroundTintList = ColorStateList.valueOf(Ui.SURFACE2)
            bar.indeterminateTintList = ColorStateList.valueOf(Ui.GREEN)
            val pc = pctOf(prog)
            bar.isIndeterminate = pc < 0
            if (pc >= 0) bar.progress = pc
            barViews[m.id] = bar
            c.addView(bar, lp(8, Ui.MATCH, dp(6)))
        } else if (failed) {
            val msg = if (m.state == "error") {
                getString(R.string.imp_failed, m.error)
            } else {
                getString(R.string.imp_interrupted)
            }
            c.addView(label(msg, 13f, Ui.RED), lp(6))
        } else {
            val meta = LinearLayout(this)
            meta.orientation = LinearLayout.HORIZONTAL
            meta.gravity = Gravity.CENTER_VERTICAL
            meta.addView(chip(if (m.fmt.isEmpty()) "?" else m.fmt, Ui.GREEN))
            val info = label(
                getString(R.string.rows_size, num(m.rows), readableSize(Datasets.diskSize(this, m.id))),
                12f, Ui.MUTED
            )
            info.setPaddingRelative(dp(8), 0, 0, 0)
            meta.addView(info)
            if (builtin) {
                val bl = label(getString(R.string.builtin), 12f, Ui.MUTED)
                bl.setPaddingRelative(dp(8), 0, 0, 0)
                meta.addView(bl)
            }
            c.addView(meta, lp(6))
        }

        c.setOnClickListener {
            if (m.state == "ready") {
                startActivity(Intent(this, SearchActivity::class.java).putExtra("id", m.id))
            } else if (importing) {
                Toast.makeText(this, R.string.still_importing, Toast.LENGTH_SHORT).show()
            }
        }
        return c
    }

    private fun confirmDelete(m: Meta) {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setMessage(R.string.confirm_delete)
            .setPositiveButton(R.string.yes) { _, _ ->
                Importer.cancel(this, m.id)
                reload()
            }
            .setNegativeButton(R.string.no, null)
            .show()
    }

    private fun pctOf(p: Importer.Prog): Int {
        if (p.total <= 0L) return -1
        if (p.phase == 0) return 0
        return ((p.done * 100) / p.total).toInt().coerceIn(0, 100)
    }

    private fun statusText(p: Importer.Prog): String {
        return when (p.phase) {
            0 -> getString(R.string.imp_queued)
            1 -> if (p.total > 0L) {
                getString(R.string.imp_copy, pctOf(p))
            } else {
                getString(R.string.imp_copy_unknown)
            }
            else -> if (p.total > 0L && p.done > 0L) {
                getString(R.string.imp_index_pct, pctOf(p), num(p.rows))
            } else {
                getString(R.string.imp_index, num(p.rows))
            }
        }
    }

    private fun num(n: Long): String = NumberFormat.getIntegerInstance().format(n)

    companion object {
        private const val REQ_PICK = 77
    }
}
