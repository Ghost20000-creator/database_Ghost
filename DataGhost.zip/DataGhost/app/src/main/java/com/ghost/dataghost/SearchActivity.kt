package com.ghost.dataghost

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** One result card inside the list. */
class ResultHolder(ctx: Context) {
    val root = FrameLayout(ctx)
    val head: TextView = ctx.label("", 13f, Ui.GREEN, true)
    val body: TextView = ctx.label("", 15f, Ui.TEXT)
    val copyB: TextView = ctx.button(ctx.getString(R.string.copy), Ui.GREEN, Color.BLACK, 13f, 8, 16)
    val saveB: TextView = ctx.button(ctx.getString(R.string.save), Ui.SURFACE2, Ui.TEXT, 13f, 8, 16)

    init {
        val c = ctx.card()
        c.addView(head)
        body.setPadding(0, ctx.dp(8), 0, ctx.dp(10))
        c.addView(body)
        val buttons = LinearLayout(ctx)
        buttons.orientation = LinearLayout.HORIZONTAL
        buttons.addView(copyB)
        val m = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        m.marginStart = ctx.dp(8)
        buttons.addView(saveB, m)
        c.addView(buttons)
        root.setPadding(0, ctx.dp(5), 0, ctx.dp(5))
        root.addView(c, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
    }
}

class SearchActivity : Activity() {
    private lateinit var meta: Meta
    private val rows = ArrayList<Row>()
    private val ui = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private var token = AtomicBoolean(false)
    private var running = false
    private var lastQuery = ""
    private var lastQ: Query? = null
    private var terms: List<String> = emptyList()
    private var ds: Dataset? = null

    private lateinit var input: EditText
    private lateinit var searchBtn: TextView
    private lateinit var spinner: ProgressBar
    private lateinit var statusTv: TextView
    private lateinit var stopBtn: TextView
    private lateinit var actionsRow: LinearLayout
    private lateinit var deepBtn: TextView
    private val adapter = ResultAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val id = intent.getStringExtra("id")
        val m = if (id == null) null else Datasets.read(Datasets.dir(this, id))
        if (m == null || m.state != "ready") {
            finish()
            return
        }
        meta = m

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.setPadding(dp(14), dp(10), dp(14), dp(6))
        root.addView(header(meta.name, chip(if (meta.fmt.isEmpty()) "?" else meta.fmt, Ui.GREEN)) { leave() })

        // query box + search button
        val qrow = LinearLayout(this)
        qrow.orientation = LinearLayout.HORIZONTAL
        qrow.gravity = Gravity.CENTER_VERTICAL

        input = EditText(this)
        input.hint = getString(R.string.search_hint)
        input.setHintTextColor(Ui.MUTED)
        input.setTextColor(Ui.TEXT)
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        input.setSingleLine(true)
        input.imeOptions = EditorInfo.IME_ACTION_SEARCH
        input.background = rounded(Ui.SURFACE, 14, Ui.STROKE, 1)
        input.setPadding(dp(14), dp(12), dp(14), dp(12))
        input.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_SEARCH) {
                startSearch()
                true
            } else {
                false
            }
        }
        qrow.addView(input, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))

        searchBtn = button(getString(R.string.search_btn), Ui.GREEN, Color.BLACK, 15f, 12, 16)
        searchBtn.setOnClickListener { startSearch() }
        val sp = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        sp.marginStart = dp(8)
        qrow.addView(searchBtn, sp)
        root.addView(qrow, lp(10))

        // status row: progress / count + stop
        val srow = LinearLayout(this)
        srow.orientation = LinearLayout.HORIZONTAL
        srow.gravity = Gravity.CENTER_VERTICAL

        spinner = ProgressBar(this)
        spinner.isIndeterminate = true
        spinner.indeterminateTintList = ColorStateList.valueOf(Ui.GREEN)
        spinner.visibility = View.GONE
        srow.addView(spinner, LinearLayout.LayoutParams(dp(22), dp(22)))

        statusTv = label("", 13f, Ui.MUTED)
        statusTv.setPadding(dp(8), 0, dp(8), 0)
        srow.addView(statusTv, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))

        stopBtn = button(getString(R.string.stop), Ui.RED, Color.WHITE, 13f, 8, 14)
        stopBtn.visibility = View.GONE
        stopBtn.setOnClickListener { token.set(true) }
        srow.addView(stopBtn)
        root.addView(srow, lp(10))

        // actions row: copy all, save all, deep search
        actionsRow = LinearLayout(this)
        actionsRow.orientation = LinearLayout.HORIZONTAL
        actionsRow.visibility = View.GONE

        val copyAllBtn = button(getString(R.string.copy_all), Ui.GREEN, Color.BLACK, 13f, 8, 12)
        copyAllBtn.setOnClickListener { copyAll() }
        actionsRow.addView(copyAllBtn)

        val saveAllBtn = button(getString(R.string.save_all), Ui.SURFACE2, Ui.TEXT, 13f, 8, 12)
        saveAllBtn.setOnClickListener { saveRows(ArrayList(rows)) }
        val sm = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        sm.marginStart = dp(6)
        actionsRow.addView(saveAllBtn, sm)

        deepBtn = button(getString(R.string.deep_btn), Ui.SURFACE2, Ui.GREEN, 13f, 8, 12)
        deepBtn.setOnClickListener {
            val q = lastQ
            if (q != null && !running) launch(q, lastQuery, true)
        }
        val dm = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        dm.marginStart = dp(6)
        actionsRow.addView(deepBtn, dm)
        root.addView(actionsRow, lp(8))

        // results list
        val list = ListView(this)
        list.adapter = adapter
        list.divider = null
        list.dividerHeight = 0
        list.selector = ColorDrawable(Color.TRANSPARENT)
        list.setCacheColorHint(Color.TRANSPARENT)
        list.isVerticalScrollBarEnabled = false
        root.addView(list, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))

        setContentView(root)
    }

    private fun leave() {
        token.set(true)
        finish()
    }

    override fun onBackPressed() {
        token.set(true)
        super.onBackPressed()
    }

    override fun onDestroy() {
        token.set(true)
        exec.execute {
            ds?.close()
            ds = null
        }
        exec.shutdown()
        super.onDestroy()
    }

    private fun startSearch() {
        val text = input.text.toString().trim()
        if (text.isEmpty() || running) return
        val q = Query(text)
        if (q.tooShort()) {
            Toast.makeText(this, R.string.short_query, Toast.LENGTH_SHORT).show()
            return
        }
        hideKeyboard()
        launch(q, text, false)
    }

    private fun launch(q: Query, text: String, deep: Boolean) {
        rows.clear()
        adapter.notifyDataSetChanged()
        lastQuery = text
        lastQ = q
        terms = q.terms
        val my = AtomicBoolean(false)
        token = my
        running = true
        setBusy(true, getString(R.string.searching))
        exec.execute { work(q, deep, my) }
    }

    /** Runs on the background thread. */
    private fun work(q: Query, deep: Boolean, my: AtomicBoolean) {
        val t0 = SystemClock.elapsedRealtime()
        var err: String? = null
        var count = 0
        var usedDeep = deep
        var partialRes = false
        try {
            val d = ds ?: Dataset.open(applicationContext, meta).also { ds = it }
            val sink = object : Sink {
                override fun onRow(row: Row) {
                    ui.post {
                        if (!my.get()) {
                            rows.add(row)
                            adapter.notifyDataSetChanged()
                        }
                    }
                }

                override fun onProgress(scanned: Long, percent: Int) {
                    ui.post {
                        if (!my.get()) {
                            statusTv.text = if (percent >= 0) {
                                getString(R.string.deep_progress, percent, rows.size)
                            } else {
                                getString(R.string.scanning, scanned, rows.size)
                            }
                        }
                    }
                }
            }
            if (deep) {
                count = d.deepSearch(q, Config.MAX_RESULTS, my, sink)
            } else {
                val ir = d.indexSearch(q, Config.MAX_RESULTS, my)
                val res: List<Row> = ir?.rows ?: emptyList()
                count = res.size
                if (res.isNotEmpty()) {
                    partialRes = ir != null && ir.partial
                    ui.post {
                        if (!my.get()) {
                            rows.addAll(res)
                            adapter.notifyDataSetChanged()
                        }
                    }
                } else if (!my.get()) {
                    // nothing in the index: look inside the text itself
                    usedDeep = true
                    ui.post {
                        if (!my.get()) statusTv.text = getString(R.string.deep_auto)
                    }
                    count = d.deepSearch(q, Config.MAX_RESULTS, my, sink)
                }
            }
        } catch (t: Throwable) {
            err = t.message ?: t.javaClass.simpleName
        }
        val ms = SystemClock.elapsedRealtime() - t0
        val e2 = err
        val c2 = count
        val ud = usedDeep
        val pr = partialRes
        ui.post { finishSearch(c2, e2, ms, ud, pr) }
    }

    private fun setBusy(busy: Boolean, msg: String) {
        spinner.visibility = if (busy) View.VISIBLE else View.GONE
        stopBtn.visibility = if (busy) View.VISIBLE else View.GONE
        searchBtn.alpha = if (busy) 0.5f else 1f
        statusTv.setTextColor(Ui.MUTED)
        statusTv.text = msg
        actionsRow.visibility = if (!busy && rows.isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun finishSearch(count: Int, err: String?, ms: Long, deepUsed: Boolean, partial: Boolean) {
        running = false
        setBusy(false, "")
        val secs = String.format(Locale.US, "%.2f", ms / 1000.0)
        if (err != null) {
            statusTv.setTextColor(Ui.RED)
            statusTv.text = getString(R.string.error_read, err)
        } else if (rows.isEmpty()) {
            statusTv.text = getString(R.string.no_results)
        } else if (partial) {
            statusTv.text = getString(R.string.results_partial_time, rows.size, secs)
        } else if (count >= Config.MAX_RESULTS) {
            statusTv.text = getString(R.string.results_capped_time, rows.size, secs)
        } else {
            statusTv.text = getString(R.string.results_time, rows.size, secs)
        }
        deepBtn.visibility = if (deepUsed) View.GONE else View.VISIBLE
    }

    private fun copyAll() {
        if (rows.isEmpty()) return
        copyText(rows.joinToString("\n\n") { it.plain() })
    }

    private fun saveRows(list: List<Row>) {
        if (list.isEmpty()) return
        val title = if (list.size == 1) {
            meta.name + ": " + lastQuery
        } else {
            meta.name + ": " + lastQuery + " (" + list.size + ")"
        }
        Store.add(this, title, list.joinToString("\n\n") { it.plain() })
        Toast.makeText(this, R.string.saved_ok, Toast.LENGTH_SHORT).show()
    }

    private inner class ResultAdapter : BaseAdapter() {
        override fun getCount(): Int = rows.size

        override fun getItem(position: Int): Any = rows[position]

        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val h: ResultHolder
            if (convertView == null) {
                h = ResultHolder(this@SearchActivity)
                h.root.tag = h
            } else {
                h = convertView.tag as ResultHolder
            }
            val r = rows[position]
            h.head.text = if (r.table.isEmpty()) r.source else r.table
            h.body.text = recordText(r, terms)
            h.copyB.setOnClickListener { this@SearchActivity.copyText(r.plain()) }
            h.saveB.setOnClickListener { this@SearchActivity.saveRows(listOf(r)) }
            return h.root
        }
    }
}
