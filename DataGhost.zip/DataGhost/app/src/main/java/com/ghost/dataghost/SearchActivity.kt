package com.ghost.dataghost

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** One result card inside the list. */
class ResultHolder(ctx: Context) {
    val root = FrameLayout(ctx)
    val head: TextView = ctx.label("", 13f, Ui.GREEN, true)
    val body: TextView = ctx.label("", 15f, Ui.TEXT)
    val copyB: TextView = ctx.button(ctx.getString(R.string.copy), Ui.GREEN, Color.BLACK, 13f, 8, 16)
    val saveB: TextView = ctx.button(ctx.getString(R.string.save), Ui.SURFACE2, Ui.TEXT, 13f, 8, 16)

    init {
        val c = ctx.card()
        c.addView(head)
        body.setPadding(0, ctx.dp(8), 0, ctx.dp(10))
        c.addView(body)
        val buttons = LinearLayout(ctx)
        buttons.orientation = LinearLayout.HORIZONTAL
        buttons.addView(copyB)
        val m = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        m.marginStart = ctx.dp(8)
        buttons.addView(saveB, m)
        c.addView(buttons)
        root.setPadding(0, ctx.dp(5), 0, ctx.dp(5))
        root.addView(c, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
    }
}

class SearchActivity : Activity() {
    private lateinit var entry: DataFile
    private val rows = ArrayList<Row>()
    private val ui = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private var token = AtomicBoolean(false)
    private var running = false
    private var lastQuery = ""
    private var terms: List<String> = emptyList()

    private lateinit var input: EditText
    private lateinit var searchBtn: TextView
    private lateinit var spinner: ProgressBar
    private lateinit var statusTv: TextView
    private lateinit var stopBtn: TextView
    private lateinit var copyAllBtn: TextView
    private lateinit var saveAllBtn: TextView
    private val adapter = ResultAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val path = intent.getStringExtra("path")
        val found = if (path == null) null else Library.get(this, path)
        if (found == null) {
            finish()
            return
        }
        entry = found

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.setPadding(dp(14), dp(10), dp(14), dp(6))
        root.addView(header(entry.name, chip(entry.fmt.label, Ui.GREEN)) { leave() })

        // query box + search button
        val qrow = LinearLayout(this)
        qrow.orientation = LinearLayout.HORIZONTAL
        qrow.gravity = Gravity.CENTER_VERTICAL

        input = EditText(this)
        input.hint = getString(R.string.search_hint)
        input.setHintTextColor(Ui.MUTED)
        input.setTextColor(Ui.TEXT)
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        input.setSingleLine(true)
        input.imeOptions = EditorInfo.IME_ACTION_SEARCH
        input.background = rounded(Ui.SURFACE, 14, Ui.STROKE, 1)
        input.setPadding(dp(14), dp(12), dp(14), dp(12))
        input.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_SEARCH) {
                startSearch()
                true
            } else {
                false
            }
        }
        qrow.addView(input, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))

        searchBtn = button(getString(R.string.search_btn), Ui.GREEN, Color.BLACK, 15f, 12, 16)
        searchBtn.setOnClickListener { startSearch() }
        val sp = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        sp.marginStart = dp(8)
        qrow.addView(searchBtn, sp)
        root.addView(qrow, lp(10))

        // status row: progress / count + stop, copy all, save all
        val srow = LinearLayout(this)
        srow.orientation = LinearLayout.HORIZONTAL
        srow.gravity = Gravity.CENTER_VERTICAL

        spinner = ProgressBar(this)
        spinner.isIndeterminate = true
        spinner.indeterminateTintList = ColorStateList.valueOf(Ui.GREEN)
        spinner.visibility = View.GONE
        srow.addView(spinner, LinearLayout.LayoutParams(dp(22), dp(22)))

        statusTv = label("", 13f, Ui.MUTED)
        statusTv.setPadding(dp(8), 0, dp(8), 0)
        srow.addView(statusTv, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))

        stopBtn = button(getString(R.string.stop), Ui.RED, Color.WHITE, 13f, 8, 14)
        stopBtn.visibility = View.GONE
        stopBtn.setOnClickListener { token.set(true) }
        srow.addView(stopBtn)

        copyAllBtn = button(getString(R.string.copy_all), Ui.GREEN, Color.BLACK, 13f, 8, 12)
        copyAllBtn.visibility = View.GONE
        copyAllBtn.setOnClickListener { copyAll() }
        srow.addView(copyAllBtn)

        saveAllBtn = button(getString(R.string.save_all), Ui.SURFACE2, Ui.TEXT, 13f, 8, 12)
        saveAllBtn.visibility = View.GONE
        saveAllBtn.setOnClickListener { saveRows(ArrayList(rows)) }
        val sm = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        sm.marginStart = dp(6)
        srow.addView(saveAllBtn, sm)

        root.addView(srow, lp(10))

        // results list
        val list = ListView(this)
        list.adapter = adapter
        list.divider = null
        list.dividerHeight = 0
        list.selector = ColorDrawable(Color.TRANSPARENT)
        list.setCacheColorHint(Color.TRANSPARENT)
        list.isVerticalScrollBarEnabled = false
        root.addView(list, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))

        setContentView(root)
    }

    private fun leave() {
        token.set(true)
        finish()
    }

    override fun onBackPressed() {
        token.set(true)
        super.onBackPressed()
    }

    override fun onDestroy() {
        token.set(true)
        exec.shutdown()
        super.onDestroy()
    }

    private fun startSearch() {
        val q = input.text.toString().trim()
        if (q.isEmpty() || running) return
        hideKeyboard()

        rows.clear()
        adapter.notifyDataSetChanged()
        lastQuery = q
        terms = Needle(q).terms

        val myToken = AtomicBoolean(false)
        token = myToken
        running = true
        setBusy(true, getString(R.string.preparing))

        val sink = object : Sink {
            override fun onRow(row: Row) {
                ui.post {
                    if (!myToken.get()) {
                        rows.add(row)
                        adapter.notifyDataSetChanged()
                    }
                }
            }

            override fun onProgress(scanned: Long) {
                ui.post {
                    if (!myToken.get()) {
                        statusTv.text = getString(R.string.scanning, scanned, rows.size)
                    }
                }
            }
        }

        exec.execute {
            var err: String? = null
            var total = 0
            try {
                val ctl = Engine.search(applicationContext, entry, q, myToken, sink)
                total = ctl.found
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val e2 = err
            val t2 = total
            ui.post { finishSearch(t2, e2) }
        }
    }

    private fun setBusy(busy: Boolean, msg: String) {
        spinner.visibility = if (busy) View.VISIBLE else View.GONE
        stopBtn.visibility = if (busy) View.VISIBLE else View.GONE
        searchBtn.alpha = if (busy) 0.5f else 1f
        statusTv.setTextColor(Ui.MUTED)
        statusTv.text = msg
        val has = !busy && rows.isNotEmpty()
        copyAllBtn.visibility = if (has) View.VISIBLE else View.GONE
        saveAllBtn.visibility = if (has) View.VISIBLE else View.GONE
    }

    private fun finishSearch(total: Int, err: String?) {
        running = false
        setBusy(false, "")
        if (err != null) {
            statusTv.setTextColor(Ui.RED)
            statusTv.text = getString(R.string.error_read, err)
        } else if (rows.isEmpty()) {
            statusTv.text = getString(R.string.no_results)
        } else if (total >= Config.MAX_RESULTS) {
            statusTv.text = getString(R.string.results_capped, rows.size)
        } else {
            statusTv.text = getString(R.string.results_count, rows.size)
        }
    }

    private fun copyAll() {
        if (rows.isEmpty()) return
        copyText(rows.joinToString("\n\n") { it.plain() })
    }

    private fun saveRows(list: List<Row>) {
        if (list.isEmpty()) return
        val title = if (list.size == 1) {
            entry.name + ": " + lastQuery
        } else {
            entry.name + ": " + lastQuery + " (" + list.size + ")"
        }
        Store.add(this, title, list.joinToString("\n\n") { it.plain() })
        Toast.makeText(this, R.string.saved_ok, Toast.LENGTH_SHORT).show()
    }

    private inner class ResultAdapter : BaseAdapter() {
        override fun getCount(): Int = rows.size

        override fun getItem(position: Int): Any = rows[position]

        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val h: ResultHolder
            if (convertView == null) {
                h = ResultHolder(this@SearchActivity)
                h.root.tag = h
            } else {
                h = convertView.tag as ResultHolder
            }
            val r = rows[position]
            h.head.text = if (r.table.isEmpty()) r.source else r.table
            h.body.text = recordText(r, terms)
            h.copyB.setOnClickListener { this@SearchActivity.copyText(r.plain()) }
            h.saveB.setOnClickListener { this@SearchActivity.saveRows(listOf(r)) }
            return h.root
        }
    }
}
