package com.ghost.dataghost

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class SavedItem(val id: Long, val title: String, val body: String, val time: Long)

object Store {
    private const val KEY = "saved"
    private var seq = 0L

    private fun prefs(c: Context) = c.getSharedPreferences("ghost", Context.MODE_PRIVATE)

    @Synchronized
    fun all(c: Context): MutableList<SavedItem> {
        val out = ArrayList<SavedItem>()
        val raw = prefs(c).getString(KEY, "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    SavedItem(o.getLong("id"), o.getString("title"), o.getString("body"), o.getLong("time"))
                )
            }
        } catch (e: Exception) {
            // corrupted data: start from an empty list
        }
        return out
    }

    @Synchronized
    fun add(c: Context, title: String, body: String) {
        val list = all(c)
        val now = System.currentTimeMillis()
        list.add(SavedItem(now * 1000 + (seq++ % 1000), title, body, now))
        write(c, list)
    }

    @Synchronized
    fun remove(c: Context, id: Long) {
        write(c, all(c).filter { it.id != id })
    }

    @Synchronized
    fun clear(c: Context) {
        write(c, emptyList())
    }

    private fun write(c: Context, items: List<SavedItem>) {
        val arr = JSONArray()
        for (s in items) {
            arr.put(
                JSONObject()
                    .put("id", s.id)
                    .put("title", s.title)
                    .put("body", s.body)
                    .put("time", s.time)
            )
        }
        prefs(c).edit().putString(KEY, arr.toString()).apply()
    }
}
