package com.ghost.dataghost

import android.content.Context
import android.content.res.AssetManager
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.util.Xml
import com.healthmarketscience.jackcess.DatabaseBuilder
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.io.Reader
import java.nio.ByteBuffer
import java.nio.CharBuffer
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.zip.ZipFile

// ---------------------------------------------------------------------------------------------
// Basic types
// ---------------------------------------------------------------------------------------------

enum class Fmt(val label: String) {
    SQLITE("SQLite"),
    ACCESS("Access"),
    XLSX("Excel"),
    XLS("Excel 97-2003"),
    TEXT("CSV / TXT")
}

/** A file found inside the APK (assets folder). */
class DataFile(val path: String, val name: String, val fmt: Fmt, val size: Long)

class Row(val source: String, val table: String, val fields: List<Pair<String, String>>) {
    fun title(): String = if (table.isEmpty()) source else "$source / $table"

    fun plain(): String {
        val sb = StringBuilder()
        sb.append(title()).append('\n')
        for ((k, v) in fields) sb.append(k).append(": ").append(v).append('\n')
        return sb.toString().trimEnd()
    }
}

/** Receives search results (index search and deep search). */
interface Sink {
    fun onRow(row: Row)
    fun onProgress(scanned: Long, percent: Int)
}

/** Receives the records read from a file while it is being imported. */
interface RecordSink {
    fun table(name: String, headers: List<String>)
    fun record(fields: List<String>)
    fun cancelled(): Boolean
    fun bytes(n: Long)
}

// ---------------------------------------------------------------------------------------------
// Text normalisation: the same rules are used when indexing and when searching
// ---------------------------------------------------------------------------------------------

object Norm {
    private fun needs(c: Char): Boolean {
        if (c < '\u0080') return c in 'A'..'Z'
        return when (c) {
            '\u0622', '\u0623', '\u0625', '\u0671', '\u0649', '\u0629', '\u0640', '\u0670' -> true
            else -> (c in '\u064B'..'\u065F') || (c in '\u0660'..'\u0669') || (c in '\u06F0'..'\u06F9') ||
                Character.isUpperCase(c) || Character.isTitleCase(c)
        }
    }

    /** Lower case, Arabic/Persian digits become 0-9, Arabic letter variants are unified, diacritics removed. */
    fun text(s: String): String {
        val n = s.length
        var i = 0
        while (i < n && !needs(s[i])) i++
        if (i == n) return s
        val sb = StringBuilder(n)
        sb.append(s, 0, i)
        while (i < n) {
            val c = s[i]
            when {
                c in 'A'..'Z' -> sb.append(c + 32)
                c in '\u0660'..'\u0669' -> sb.append('0' + (c - '\u0660'))
                c in '\u06F0'..'\u06F9' -> sb.append('0' + (c - '\u06F0'))
                c == '\u0622' || c == '\u0623' || c == '\u0625' || c == '\u0671' -> sb.append('\u0627')
                c == '\u0649' -> sb.append('\u064A')
                c == '\u0629' -> sb.append('\u0647')
                c == '\u0640' || c == '\u0670' || c in '\u064B'..'\u065F' -> {
                    // diacritics and tatweel are dropped
                }
                c < '\u0080' -> sb.append(c)
                else -> sb.append(Character.toLowerCase(c))
            }
            i++
        }
        return sb.toString()
    }

    /** Characters that make up a word in the index. */
    fun isTok(c: Char): Boolean {
        if (c < '\u0080') return (c in 'a'..'z') || (c in 'A'..'Z') || (c in '0'..'9')
        if (Character.isLetterOrDigit(c)) return true
        val t = Character.getType(c)
        return t == Character.LETTER_NUMBER.toInt() || t == Character.OTHER_NUMBER.toInt() ||
            t == Character.PRIVATE_USE.toInt()
    }

    /**
     * Text stored in the search index: normalized, only letters/digits and spaces.
     * Long numbers also get their last 10 digits as an extra word, so a phone number is found
     * whether it was saved with a country code, with a leading 0, or without.
     */
    fun indexText(fields: List<String>): String {
        val joined = StringBuilder()
        for (f in fields) {
            if (f.isEmpty()) continue
            joined.append(f).append(' ')
        }
        val t = text(joined.toString())
        val out = StringBuilder(t.length + 16)
        val extra = StringBuilder()
        var runStart = -1
        for (i in 0..t.length) {
            val c = if (i < t.length) t[i] else ' '
            if (c in '0'..'9') {
                if (runStart < 0) runStart = i
            } else if (runStart >= 0) {
                if (i - runStart >= 11) extra.append(' ').append(t, i - 10, i)
                runStart = -1
            }
            if (i < t.length) out.append(if (isTok(c)) c else ' ')
        }
        if (extra.isNotEmpty()) out.append(extra)
        return out.toString()
    }
}

// ---------------------------------------------------------------------------------------------
// What the user typed
// ---------------------------------------------------------------------------------------------

class Query(raw: String) {
    /** One entry per typed word; each entry lists the spellings (normalized) that count as a match. */
    val words: List<List<String>>

    /** Flat list used to highlight matches. */
    val terms: List<String>

    init {
        val nz = Norm.text(raw.trim())
        // a phone number typed with spaces or dashes ("+964 770 123 4567") is one word
        val sbc = StringBuilder()
        for (ch in nz) {
            if (ch != ' ' && ch != '-' && ch != '(' && ch != ')' && ch != '.' && ch != '+' && ch != '\u00A0') {
                sbc.append(ch)
            }
        }
        val compact = sbc.toString()
        val list = ArrayList<List<String>>()
        if (compact.length != nz.length && compact.length >= 7 && compact.all { it in '0'..'9' }) {
            list.add(variants(compact))
        } else {
            for (w in nz.split(' ', '\t', '\n', '\u00A0')) {
                if (w.isNotEmpty()) list.add(variants(w))
            }
        }
        words = list
        terms = list.flatten().distinct()
    }

    private fun variants(w: String): List<String> {
        val out = LinkedHashSet<String>()
        out.add(w)
        if (w.isNotEmpty() && w.all { it in '0'..'9' }) {
            val z = w.trimStart('0')
            if (w.length >= 8 && z.length >= 6 && z != w) out.add(z)
            if (w.length >= 11) out.add(w.substring(w.length - 10))
        }
        return out.toList()
    }

    fun tooShort(): Boolean = words.none { w -> w.any { it.length >= 2 } }

    /** True when the (normalized) record text contains every typed word. */
    fun matches(body: String): Boolean {
        if (words.isEmpty()) return false
        for (w in words) {
            var ok = false
            for (v in w) {
                if (body.contains(v)) {
                    ok = true
                    break
                }
            }
            if (!ok) return false
        }
        return true
    }

    private fun ftsAlt(v: String): String? {
        val parts = ArrayList<String>()
        val sb = StringBuilder()
        for (ch in v) {
            if (Norm.isTok(ch)) {
                sb.append(ch)
            } else if (sb.isNotEmpty()) {
                parts.add(sb.toString())
                sb.setLength(0)
            }
        }
        if (sb.isNotEmpty()) parts.add(sb.toString())
        if (parts.isEmpty()) return null
        val last = parts[parts.size - 1]
        if (parts.size == 1) return if (last.length >= 2) "$last*" else null
        return "\"" + parts.subList(0, parts.size - 1).joinToString(" ") + " " + last + "*\""
    }

    /** Queries for the full-text index (a few at most; their results are merged). */
    fun ftsQueries(): List<String> {
        var combos: List<List<String>> = listOf(emptyList())
        for (w in words) {
            val alts = ArrayList<String>()
            for (v in w) {
                val a = ftsAlt(v)
                if (a != null && !alts.contains(a)) alts.add(a)
            }
            if (alts.isEmpty()) continue
            val next = ArrayList<List<String>>()
            for (c in combos) {
                for (a in alts) {
                    if (next.size < 8) next.add(c + a)
                }
            }
            combos = next
        }
        return combos.filter { it.isNotEmpty() }.map { it.joinToString(" ") }
    }
}

// ---------------------------------------------------------------------------------------------
// Files bundled inside the APK (assets) and format detection
// ---------------------------------------------------------------------------------------------

object Library {
    private val SKIP_FILES = setOf("put_data_files_here")

    fun apkStamp(ctx: Context): Long = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime
    } catch (e: Exception) {
        0L
    }

    /**
     * Lists ONLY the files stored inside this app's own APK (assets folder).
     * AssetManager.list() also returns files that belong to the Android system on some phones,
     * so the APK itself is read instead.
     */
    fun list(ctx: Context): List<DataFile> {
        val out = ArrayList<DataFile>()
        var readApk = false
        val info = ctx.applicationInfo
        val apks = ArrayList<String>()
        apks.add(info.sourceDir)
        val splits = info.splitSourceDirs
        if (splits != null) apks.addAll(splits)
        for (apk in apks) {
            try {
                val zf = ZipFile(apk)
                try {
                    val en = zf.entries()
                    while (en.hasMoreElements()) {
                        val z = en.nextElement()
                        if (z.isDirectory || !z.name.startsWith("assets/")) continue
                        val path = z.name.substring(7)
                        if (path.startsWith("dexopt/")) continue
                        val name = path.substringAfterLast('/')
                        if (name in SKIP_FILES) continue
                        val head = ByteArray(32)
                        var n = 0
                        val ins = zf.getInputStream(z)
                        try {
                            while (n < head.size) {
                                val r = ins.read(head, n, head.size - n)
                                if (r < 0) break
                                n += r
                            }
                        } finally {
                            ins.close()
                        }
                        out.add(DataFile(path, name, sniff(head, n, name), z.size))
                    }
                    readApk = true
                } finally {
                    zf.close()
                }
            } catch (e: Exception) {
                // try the next file, or fall back below
            }
        }
        if (!readApk) walk(ctx.assets, "data", out)
        out.sortBy { it.name.lowercase() }
        return out
    }

    private fun walk(am: AssetManager, dir: String, out: MutableList<DataFile>) {
        val names = (try {
            am.list(dir)
        } catch (e: IOException) {
            null
        }) ?: return
        for (n in names) {
            val p = if (dir.isEmpty()) n else "$dir/$n"
            val kids = try {
                am.list(p)
            } catch (e: IOException) {
                null
            }
            if (kids != null && kids.isNotEmpty()) {
                walk(am, p, out)
            } else {
                if (n in SKIP_FILES) continue
                val d = describe(am, p, n)
                if (d != null) out.add(d)
            }
        }
    }

    private fun describe(am: AssetManager, path: String, name: String): DataFile? {
        return try {
            val head = ByteArray(32)
            var n = 0
            am.open(path).use { ins ->
                while (n < head.size) {
                    val r = ins.read(head, n, head.size - n)
                    if (r < 0) break
                    n += r
                }
            }
            DataFile(path, name, sniff(head, n, name), -1L)
        } catch (e: Exception) {
            null
        }
    }

    /** Detects the real format from the first bytes; the extension is only a fallback. */
    fun sniff(h: ByteArray, n: Int, name: String): Fmt {
        fun b(i: Int): Int = if (i < n) h[i].toInt() and 0xFF else -1

        if (n >= 15 && String(h, 0, 15, Charsets.ISO_8859_1) == "SQLite format 3") return Fmt.SQLITE
        if (n >= 19 && b(0) == 0 && b(1) == 1 && b(2) == 0 && b(3) == 0) {
            val s = String(h, 4, 15, Charsets.ISO_8859_1)
            if (s == "Standard Jet DB" || s == "Standard ACE DB") return Fmt.ACCESS
        }
        if (b(0) == 0xD0 && b(1) == 0xCF && b(2) == 0x11 && b(3) == 0xE0) return Fmt.XLS
        if (b(0) == 0x50 && b(1) == 0x4B && b(2) == 0x03 && b(3) == 0x04) return Fmt.XLSX
        if ((b(0) == 0xFF && b(1) == 0xFE) || (b(0) == 0xFE && b(1) == 0xFF)) return Fmt.TEXT

        var hasNul = false
        for (i in 0 until n) if (h[i].toInt() == 0) hasNul = true
        if (!hasNul) return Fmt.TEXT

        return when (name.substringAfterLast('.', "").lowercase()) {
            "mdb", "accdb", "accdr", "accde", "access" -> Fmt.ACCESS
            "xlsx", "xlsm" -> Fmt.XLSX
            "xls", "xsl" -> Fmt.XLS
            "db", "sqlite", "sqlite3", "db3" -> Fmt.SQLITE
            else -> Fmt.TEXT
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Readers: every format is turned into a stream of records
// ---------------------------------------------------------------------------------------------

/** Counts the bytes that were read, used for the progress bar. */
class CountingStream(ins: InputStream) : FilterInputStream(ins) {
    @Volatile
    var count = 0L

    override fun read(): Int {
        val b = super.read()
        if (b >= 0) count++
        return b
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        val n = super.read(b, off, len)
        if (n > 0) count += n
        return n
    }
}

/** Reads lines without ever holding a huge line in memory (very long lines are cut into pieces). */
class LineReader(private val r: Reader, private val maxLen: Int = 200_000) {
    private val buf = CharArray(1 shl 16)
    private var pos = 0
    private var lim = 0
    private var eof = false
    private val sb = StringBuilder()

    private fun fill(): Boolean {
        if (eof) return false
        val n = r.read(buf, 0, buf.size)
        if (n <= 0) {
            eof = true
            lim = 0
            pos = 0
            return false
        }
        lim = n
        pos = 0
        return true
    }

    fun readLine(): String? {
        sb.setLength(0)
        var any = false
        while (true) {
            if (pos >= lim && !fill()) {
                return if (any) sb.toString() else null
            }
            var i = pos
            while (i < lim) {
                val c = buf[i]
                if (c == '\n' || c == '\r') break
                i++
            }
            if (i > pos) {
                sb.append(buf, pos, i - pos)
                any = true
            }
            if (i < lim) {
                val c = buf[i]
                pos = i + 1
                if (c == '\r') {
                    if (pos >= lim) fill()
                    if (pos < lim && buf[pos] == '\n') pos++
                }
                return sb.toString()
            }
            pos = lim
            if (sb.length >= maxLen) return sb.toString()
        }
    }
}

object TextParser {
    fun parse(open: () -> InputStream, sink: RecordSink) {
        val sample = ByteArray(64 * 1024)
        var n = 0
        val s0 = open()
        try {
            while (n < sample.size) {
                val r = s0.read(sample, n, sample.size - n)
                if (r < 0) break
                n += r
            }
        } finally {
            s0.close()
        }
        if (n == 0) return

        val cs = detectCharset(sample, n)
        val lines = sampleLines(sample, n, cs)
        val delim = detectDelimiter(lines)

        var headers: List<String> = emptyList()
        var hasHeader = false
        if (delim != null && lines.isNotEmpty()) {
            val cells = splitLine(lines[0], delim).map { it.trim() }
            val nb = cells.filter { it.isNotEmpty() }
            if (nb.size >= 2 && nb.none { c -> c.any { ch -> ch.isDigit() } }) {
                headers = cells
                hasHeader = true
            }
        }
        sink.table("", headers)

        val cin = CountingStream(open())
        try {
            val lr = LineReader(InputStreamReader(cin, cs))
            var first = true
            var k = 0
            while (true) {
                val raw = lr.readLine() ?: break
                if (raw.isBlank()) continue
                var line = raw
                if (first) {
                    first = false
                    line = line.removePrefix("\uFEFF")
                    if (hasHeader) continue
                }
                val fields = if (delim == null) listOf(line) else splitLine(line, delim)
                sink.record(fields)
                k++
                if ((k and 0xFFF) == 0) {
                    sink.bytes(cin.count)
                    if (sink.cancelled()) break
                }
            }
            sink.bytes(cin.count)
        } finally {
            cin.close()
        }
    }

    private fun detectCharset(b: ByteArray, n: Int): Charset {
        if (n >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte()) return Charsets.UTF_8
        if (n >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) return Charsets.UTF_16LE
        if (n >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte()) return Charsets.UTF_16BE
        val dec = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        val out = CharBuffer.allocate(n + 8)
        val res = dec.decode(ByteBuffer.wrap(b, 0, n), out, false)
        // not valid UTF-8: most Arabic files saved by old tools use Windows-1256
        return if (res.isError) Charset.forName("windows-1256") else Charsets.UTF_8
    }

    private fun sampleLines(b: ByteArray, n: Int, cs: Charset): List<String> {
        val text = String(b, 0, n, cs).removePrefix("\uFEFF")
        val parts = text.split("\r\n", "\n", "\r")
        val usable = if (n == b.size && parts.size > 1) parts.dropLast(1) else parts
        return usable.filter { it.isNotBlank() }.take(30)
    }

    private fun detectDelimiter(lines: List<String>): Char? {
        if (lines.isEmpty()) return null
        var best: Char? = null
        var bestScore = 0.0
        for (d in charArrayOf('\t', '|', ';', ',', ':')) {
            val counts = lines.map { l -> l.count { it == d } }
            val modal = counts.groupingBy { it }.eachCount().maxByOrNull { it.value } ?: continue
            if (modal.key == 0) continue
            val score = modal.value.toDouble() / counts.size
            if (score >= 0.7 && score > bestScore + 1e-9) {
                best = d
                bestScore = score
            }
        }
        return best
    }

    private fun splitLine(line: String, d: Char): List<String> {
        if (d == '\t' || d == '|' || d == ':') return line.split(d)
        // comma / semicolon: respect "quoted, values"
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            if (c == '"') {
                if (quoted && i + 1 < line.length && line[i + 1] == '"') {
                    sb.append('"')
                    i++
                } else {
                    quoted = !quoted
                }
            } else if (c == d && !quoted) {
                out.add(sb.toString())
                sb.setLength(0)
            } else {
                sb.append(c)
            }
            i++
        }
        out.add(sb.toString())
        return out
    }
}

/** Turns the rows of an Excel sheet into records; the first row is used as titles when it looks like titles. */
class SheetEmitter(private val name: String, private val sink: RecordSink) {
    private var started = false

    fun row(cells: List<String>) {
        if (!started) {
            if (cells.all { it.isBlank() }) return
            started = true
            val nb = cells.filter { it.isNotBlank() }
            if (nb.size >= 2 && nb.none { c -> c.any { ch -> ch.isDigit() } }) {
                sink.table(name, cells.map { it.trim() })
                return
            }
            sink.table(name, emptyList())
        }
        sink.record(cells)
    }
}

object SqliteParser {
    fun parse(file: File, sink: RecordSink) {
        val db = SQLiteDatabase.openDatabase(
            file.path, null,
            SQLiteDatabase.OPEN_READONLY or SQLiteDatabase.NO_LOCALIZED_COLLATORS
        )
        try {
            val tables = ArrayList<String>()
            val tc = db.rawQuery(
                "SELECT name FROM sqlite_master WHERE type IN ('table','view') " +
                    "AND name NOT LIKE 'sqlite_%' AND name NOT LIKE 'android_%'",
                null
            )
            try {
                while (tc.moveToNext()) tables.add(tc.getString(0))
            } finally {
                tc.close()
            }
            for (t in tables) {
                if (sink.cancelled()) break
                val c = db.rawQuery("SELECT * FROM \"" + t.replace("\"", "\"\"") + "\"", null)
                try {
                    val n = c.columnCount
                    val names = ArrayList<String>(n)
                    for (i in 0 until n) names.add(c.getColumnName(i))
                    sink.table(t, names)
                    val vals = ArrayList<String>(n)
                    var k = 0
                    while (c.moveToNext()) {
                        vals.clear()
                        for (i in 0 until n) {
                            val ty = c.getType(i)
                            if (ty == Cursor.FIELD_TYPE_NULL || ty == Cursor.FIELD_TYPE_BLOB) {
                                vals.add("")
                            } else {
                                vals.add(c.getString(i) ?: "")
                            }
                        }
                        sink.record(vals)
                        k++
                        if ((k and 0xFFF) == 0 && sink.cancelled()) break
                    }
                } finally {
                    c.close()
                }
            }
        } finally {
            db.close()
        }
    }
}

object AccessParser {
    private val df = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    private fun str(v: Any?): String = when (v) {
        null -> ""
        is ByteArray -> ""
        is Array<*> -> ""
        is java.util.Date -> synchronized(df) { df.format(v) }
        else -> v.toString()
    }

    fun parse(file: File, sink: RecordSink) {
        val db = DatabaseBuilder(file).setReadOnly(true).open()
        try {
            var ok = 0
            var lastErr: Exception? = null
            for (tn in db.tableNames) {
                if (sink.cancelled()) break
                try {
                    val table = db.getTable(tn) ?: continue
                    val cols = table.columns.map { it.name }
                    sink.table(tn, cols)
                    val vals = ArrayList<String>(cols.size)
                    var k = 0
                    for (row in table) {
                        vals.clear()
                        for (c in cols) vals.add(str(row[c]).trim())
                        sink.record(vals)
                        k++
                        if ((k and 0xFFF) == 0 && sink.cancelled()) break
                    }
                    ok++
                } catch (ex: Exception) {
                    lastErr = ex
                }
            }
            val le = lastErr
            if (ok == 0 && le != null) throw le
        } finally {
            db.close()
        }
    }
}

object XlsxParser {
    fun parse(file: File, sink: RecordSink) {
        val zf = ZipFile(file)
        try {
            val shared = ArrayList<String>()
            val ss = zf.getEntry("xl/sharedStrings.xml")
            if (ss != null) {
                val ins = zf.getInputStream(ss)
                try {
                    parseShared(ins, shared)
                } finally {
                    ins.close()
                }
            }
            for ((name, path) in sheetList(zf)) {
                if (sink.cancelled()) break
                val en = zf.getEntry(path) ?: continue
                val ins = zf.getInputStream(en)
                try {
                    scanSheet(ins, SheetEmitter(name, sink), shared, sink)
                } finally {
                    ins.close()
                }
            }
        } finally {
            zf.close()
        }
    }

    private fun parseShared(input: InputStream, out: MutableList<String>) {
        val p = Xml.newPullParser()
        p.setInput(input, null)
        var sb: StringBuilder? = null
        var inT = false
        var inPh = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "si" -> sb = StringBuilder()
                    "t" -> inT = true
                    "rPh" -> inPh = true
                }
                XmlPullParser.TEXT -> if (inT && !inPh) sb?.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "t" -> inT = false
                    "rPh" -> inPh = false
                    "si" -> {
                        out.add(sb?.toString() ?: "")
                        sb = null
                    }
                }
            }
            ev = p.next()
        }
    }

    /** Sheet names and the zip path of each sheet, in workbook order. */
    private fun sheetList(zf: ZipFile): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        try {
            val rels = HashMap<String, String>()
            val re = zf.getEntry("xl/_rels/workbook.xml.rels")
            if (re != null) {
                val ins = zf.getInputStream(re)
                try {
                    val p = Xml.newPullParser()
                    p.setInput(ins, null)
                    var ev = p.eventType
                    while (ev != XmlPullParser.END_DOCUMENT) {
                        if (ev == XmlPullParser.START_TAG && p.name == "Relationship") {
                            val id = p.getAttributeValue(null, "Id")
                            val tg = p.getAttributeValue(null, "Target")
                            if (id != null && tg != null) {
                                rels[id] = if (tg.startsWith("/")) tg.substring(1) else "xl/$tg"
                            }
                        }
                        ev = p.next()
                    }
                } finally {
                    ins.close()
                }
            }
            val we = zf.getEntry("xl/workbook.xml")
            if (we != null) {
                val ins = zf.getInputStream(we)
                try {
                    val p = Xml.newPullParser()
                    p.setInput(ins, null)
                    var ev = p.eventType
                    while (ev != XmlPullParser.END_DOCUMENT) {
                        if (ev == XmlPullParser.START_TAG && p.name == "sheet") {
                            val nm = p.getAttributeValue(null, "name") ?: "Sheet"
                            var rid: String? = null
                            for (i in 0 until p.attributeCount) {
                                val an = p.getAttributeName(i)
                                if (an == "r:id" || an.endsWith(":id")) rid = p.getAttributeValue(i)
                            }
                            val target = if (rid != null) rels[rid] else null
                            if (target != null) out.add(nm to target)
                        }
                        ev = p.next()
                    }
                } finally {
                    ins.close()
                }
            }
        } catch (ex: Exception) {
            // fall back to the file names below
        }
        if (out.isEmpty()) {
            val names = ArrayList<String>()
            val en = zf.entries()
            while (en.hasMoreElements()) {
                val z = en.nextElement()
                if (z.name.startsWith("xl/worksheets/") && z.name.endsWith(".xml")) names.add(z.name)
            }
            names.sort()
            for (i in names.indices) out.add("Sheet ${i + 1}" to names[i])
        }
        return out
    }

    private fun colIndex(ref: String?): Int {
        if (ref == null) return -1
        var n = 0
        var any = false
        for (ch in ref) {
            val up = ch.uppercaseChar()
            if (up in 'A'..'Z') {
                n = n * 26 + (up - 'A' + 1)
                any = true
            } else {
                break
            }
        }
        return if (any) n - 1 else -1
    }

    private fun scanSheet(input: InputStream, emitter: SheetEmitter, shared: List<String>, sink: RecordSink) {
        val p = Xml.newPullParser()
        p.setInput(input, null)
        val cells = ArrayList<String>()
        val sb = StringBuilder()
        var type = ""
        var col = 0
        var inVal = false
        var rowsSeen = 0
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "row" -> cells.clear()
                    "c" -> {
                        type = p.getAttributeValue(null, "t") ?: ""
                        val ci = colIndex(p.getAttributeValue(null, "r"))
                        col = if (ci >= 0) ci else cells.size
                        sb.setLength(0)
                    }
                    "v", "t" -> inVal = true
                }
                XmlPullParser.TEXT -> if (inVal) sb.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "v", "t" -> inVal = false
                    "c" -> {
                        val raw = sb.toString()
                        val value = when (type) {
                            "s" -> {
                                val ix = raw.trim().toIntOrNull()
                                if (ix != null && ix >= 0 && ix < shared.size) shared[ix] else raw
                            }
                            "b" -> if (raw.trim() == "1") "TRUE" else "FALSE"
                            else -> raw
                        }
                        while (cells.size <= col) cells.add("")
                        cells[col] = value
                    }
                    "row" -> {
                        emitter.row(ArrayList(cells))
                        rowsSeen++
                        if ((rowsSeen and 0xFFF) == 0 && sink.cancelled()) return
                    }
                }
            }
            ev = p.next()
        }
    }
}

object XlsParser {
    fun parse(file: File, sink: RecordSink) {
        System.setProperty("jxl.nogc", "true")
        val wb = jxl.Workbook.getWorkbook(file)
        try {
            for (sheet in wb.sheets) {
                if (sink.cancelled()) break
                val emitter = SheetEmitter(sheet.name, sink)
                val rows = sheet.rows
                for (r in 0 until rows) {
                    if ((r and 0xFFF) == 0 && sink.cancelled()) break
                    val cells = sheet.getRow(r)
                    emitter.row(cells.map { it.contents ?: "" })
                }
            }
        } finally {
            wb.close()
        }
    }
}
