package com.ghost.dataghost

import android.content.Context
import android.content.res.AssetManager
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.os.SystemClock
import android.util.Xml
import com.healthmarketscience.jackcess.DatabaseBuilder
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.CharBuffer
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipFile

// ---------------------------------------------------------------------------------------------
// Basic types
// ---------------------------------------------------------------------------------------------

enum class Fmt(val label: String) {
    SQLITE("SQLite"),
    ACCESS("Access"),
    XLSX("Excel"),
    XLS("Excel 97-2003"),
    TEXT("CSV / TXT")
}

class DataFile(val path: String, val name: String, val fmt: Fmt, val size: Long)

class Row(val source: String, val table: String, val fields: List<Pair<String, String>>) {
    fun title(): String = if (table.isEmpty()) source else "$source / $table"

    fun plain(): String {
        val sb = StringBuilder()
        sb.append(title()).append('\n')
        for ((k, v) in fields) sb.append(k).append(": ").append(v).append('\n')
        return sb.toString().trimEnd()
    }
}

interface Sink {
    fun onRow(row: Row)
    fun onProgress(scanned: Long)
}

/** Shared state of one search: cancel flag, result limit, counters. */
class Ctl(private val cancel: AtomicBoolean, private val limit: Int, private val sink: Sink) {
    var found = 0
    var scanned = 0L
    private var tick = 0L

    fun stop(): Boolean = cancel.get() || found >= limit

    fun emit(r: Row) {
        sink.onRow(r)
        found++
    }

    fun scan() {
        scanned++
        if ((scanned and 0x3FFL) == 0L) {
            val now = SystemClock.uptimeMillis()
            if (now - tick >= 250L) {
                tick = now
                sink.onProgress(scanned)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Files bundled inside the APK (assets) and format detection
// ---------------------------------------------------------------------------------------------

object Library {
    private val SKIP_DIRS = setOf("images", "sounds", "webkit")
    private val SKIP_FILES = setOf("put_data_files_here")

    fun list(ctx: Context): List<DataFile> {
        val out = ArrayList<DataFile>()
        walk(ctx.assets, "", out)
        out.sortBy { it.name.lowercase() }
        return out
    }

    fun get(ctx: Context, path: String): DataFile? =
        describe(ctx.assets, path, path.substringAfterLast('/'))

    private fun walk(am: AssetManager, dir: String, out: MutableList<DataFile>) {
        val names = (try {
            am.list(dir)
        } catch (e: IOException) {
            null
        }) ?: return
        for (n in names) {
            val p = if (dir.isEmpty()) n else "$dir/$n"
            val kids = try {
                am.list(p)
            } catch (e: IOException) {
                null
            }
            if (kids != null && kids.isNotEmpty()) {
                if (dir.isEmpty() && n in SKIP_DIRS) continue
                walk(am, p, out)
            } else {
                if (n in SKIP_FILES) continue
                val d = describe(am, p, n)
                if (d != null) out.add(d)
            }
        }
    }

    private fun describe(am: AssetManager, path: String, name: String): DataFile? {
        return try {
            val head = ByteArray(32)
            var n = 0
            am.open(path).use { ins ->
                while (n < head.size) {
                    val r = ins.read(head, n, head.size - n)
                    if (r < 0) break
                    n += r
                }
            }
            var size = -1L
            try {
                val fd = am.openFd(path)
                size = fd.length
                fd.close()
            } catch (e: Exception) {
                // compressed asset: size unknown until it is opened
            }
            DataFile(path, name, sniff(head, n, name), size)
        } catch (e: Exception) {
            null
        }
    }

    /** Detects the real format from the first bytes; the extension is only a fallback. */
    fun sniff(h: ByteArray, n: Int, name: String): Fmt {
        fun b(i: Int): Int = if (i < n) h[i].toInt() and 0xFF else -1

        if (n >= 15 && String(h, 0, 15, Charsets.ISO_8859_1) == "SQLite format 3") return Fmt.SQLITE
        if (n >= 19 && b(0) == 0 && b(1) == 1 && b(2) == 0 && b(3) == 0) {
            val s = String(h, 4, 15, Charsets.ISO_8859_1)
            if (s == "Standard Jet DB" || s == "Standard ACE DB") return Fmt.ACCESS
        }
        if (b(0) == 0xD0 && b(1) == 0xCF && b(2) == 0x11 && b(3) == 0xE0) return Fmt.XLS
        if (b(0) == 0x50 && b(1) == 0x4B && b(2) == 0x03 && b(3) == 0x04) return Fmt.XLSX
        if ((b(0) == 0xFF && b(1) == 0xFE) || (b(0) == 0xFE && b(1) == 0xFF)) return Fmt.TEXT

        var hasNul = false
        for (i in 0 until n) if (h[i].toInt() == 0) hasNul = true
        if (!hasNul) return Fmt.TEXT

        return when (name.substringAfterLast('.', "").lowercase()) {
            "mdb", "accdb", "accdr", "accde", "access" -> Fmt.ACCESS
            "xlsx", "xlsm" -> Fmt.XLSX
            "xls", "xsl" -> Fmt.XLS
            "db", "sqlite", "sqlite3", "db3" -> Fmt.SQLITE
            else -> Fmt.TEXT
        }
    }

    /** Some readers need a real file: copy the asset once into private storage and reuse it. */
    fun fileFor(ctx: Context, e: DataFile): File {
        val dir = File(ctx.filesDir, "cache_data")
        val stamp = try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime
        } catch (ex: Exception) {
            0L
        }
        val prefs = ctx.getSharedPreferences("ghost", Context.MODE_PRIVATE)
        if (prefs.getLong("cache_stamp", -1L) != stamp) {
            dir.deleteRecursively()
            prefs.edit().putLong("cache_stamp", stamp).apply()
        }
        dir.mkdirs()
        val f = File(dir, e.path.replace('/', '_'))
        if (!f.exists() || f.length() == 0L) {
            val tmp = File(dir, f.name + ".tmp")
            ctx.assets.open(e.path, AssetManager.ACCESS_STREAMING).use { input ->
                FileOutputStream(tmp).use { out -> input.copyTo(out, 1 shl 16) }
            }
            tmp.renameTo(f)
        }
        return f
    }
}

// ---------------------------------------------------------------------------------------------
// Query matching: every word must appear (any order); Arabic/English digits are treated the same
// ---------------------------------------------------------------------------------------------

class Needle(query: String) {
    /** One entry per typed word; each entry holds the spellings that count as a match. */
    val tokens: List<List<String>>

    /** Flat list used to highlight matches. */
    val terms: List<String>

    init {
        val parts = query.trim().lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        tokens = parts.map { variants(it) }
        terms = tokens.flatten().distinct()
    }

    fun matches(text: String): Boolean {
        if (tokens.isEmpty()) return false
        val t = text.lowercase()
        for (vs in tokens) {
            var ok = false
            for (v in vs) {
                if (t.contains(v)) {
                    ok = true
                    break
                }
            }
            if (!ok) return false
        }
        return true
    }

    companion object {
        private fun toAscii(s: String): String {
            val sb = StringBuilder(s.length)
            for (ch in s) {
                when (ch) {
                    in '\u0660'..'\u0669' -> sb.append('0' + (ch - '\u0660'))
                    in '\u06F0'..'\u06F9' -> sb.append('0' + (ch - '\u06F0'))
                    else -> sb.append(ch)
                }
            }
            return sb.toString()
        }

        private fun toIndic(s: String): String {
            val sb = StringBuilder(s.length)
            for (ch in s) {
                when (ch) {
                    in '0'..'9' -> sb.append('\u0660' + (ch - '0'))
                    else -> sb.append(ch)
                }
            }
            return sb.toString()
        }

        private fun variants(tok: String): List<String> {
            val set = LinkedHashSet<String>()
            val a = toAscii(tok)
            set.add(tok)
            set.add(a)
            set.add(toIndic(a))
            // long numbers: also try without the leading zero (0770... vs 770...)
            for (v in ArrayList(set)) {
                if (v.length >= 7 && v[0] == '0' && v.all { it.isDigit() }) {
                    val z = v.trimStart('0')
                    if (z.isNotEmpty()) set.add(z)
                }
            }
            return set.toList()
        }
    }
}

/** Turns table-like rows (Excel sheets) into results; the first row is used as titles when it looks like titles. */
class SheetFeeder(
    private val source: String,
    private val sheet: String,
    private val colWord: String,
    private val needle: Needle,
    private val ctl: Ctl
) {
    private var headers: List<String>? = null
    private var started = false

    fun feed(cells: List<String>) {
        if (!started) {
            if (cells.all { it.isBlank() }) return
            started = true
            val nb = cells.filter { it.isNotBlank() }
            if (nb.size >= 2 && nb.none { c -> c.any { ch -> ch.isDigit() } }) {
                headers = cells.map { it.trim() }
                return
            }
        }
        val sb = StringBuilder()
        for (c in cells) {
            if (c.isNotEmpty()) sb.append(c).append(' ')
        }
        if (!needle.matches(sb.toString())) return
        val hs = headers
        val f = ArrayList<Pair<String, String>>()
        for (i in cells.indices) {
            val v = cells[i].trim()
            if (v.isEmpty()) continue
            val h = if (hs != null && i < hs.size) hs[i] else ""
            f.add((if (h.isEmpty()) "$colWord ${i + 1}" else h) to v)
        }
        if (f.isNotEmpty()) ctl.emit(Row(source, sheet, f))
    }
}

// ---------------------------------------------------------------------------------------------
// CSV / TXT (any text file, streamed line by line, never fully loaded in memory)
// ---------------------------------------------------------------------------------------------

object TextEngine {
    fun search(ctx: Context, e: DataFile, needle: Needle, ctl: Ctl) {
        val colWord = ctx.getString(R.string.col)
        val lineWord = ctx.getString(R.string.line)

        val sample = ByteArray(64 * 1024)
        var n = 0
        ctx.assets.open(e.path).use { ins ->
            while (n < sample.size) {
                val r = ins.read(sample, n, sample.size - n)
                if (r < 0) break
                n += r
            }
        }
        if (n == 0) return

        val cs = detectCharset(sample, n)
        val lines = sampleLines(sample, n, cs)
        val delim = detectDelimiter(lines)

        var headers: List<String>? = null
        if (delim != null && lines.isNotEmpty()) {
            val cells = splitLine(lines[0], delim).map { it.trim() }
            val nb = cells.filter { it.isNotEmpty() }
            if (nb.size >= 2 && nb.none { c -> c.any { ch -> ch.isDigit() } }) headers = cells
        }
        val hdr = headers

        var lineNo = 0L
        ctx.assets.open(e.path, AssetManager.ACCESS_STREAMING).use { raw ->
            val br = BufferedReader(InputStreamReader(raw, cs), 1 shl 16)
            while (!ctl.stop()) {
                var line = br.readLine() ?: break
                if (line.isBlank()) continue
                lineNo++
                if (lineNo == 1L) {
                    line = line.removePrefix("\uFEFF")
                    if (hdr != null) continue
                }
                ctl.scan()
                if (!needle.matches(line)) continue
                ctl.emit(makeRow(e, line, delim, hdr, colWord, lineWord))
            }
        }
    }

    private fun makeRow(
        e: DataFile,
        line: String,
        delim: Char?,
        headers: List<String>?,
        colWord: String,
        lineWord: String
    ): Row {
        if (delim == null) return Row(e.name, "", listOf(lineWord to line.trim()))
        val cells = splitLine(line, delim)
        val f = ArrayList<Pair<String, String>>()
        for (i in cells.indices) {
            val v = cells[i].trim()
            if (v.isEmpty()) continue
            val h = if (headers != null && i < headers.size) headers[i] else ""
            f.add((if (h.isEmpty()) "$colWord ${i + 1}" else h) to v)
        }
        if (f.isEmpty()) f.add(lineWord to line.trim())
        return Row(e.name, "", f)
    }

    private fun detectCharset(b: ByteArray, n: Int): Charset {
        if (n >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte()) return Charsets.UTF_8
        if (n >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) return Charsets.UTF_16LE
        if (n >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte()) return Charsets.UTF_16BE
        val dec = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        val out = CharBuffer.allocate(n + 8)
        val res = dec.decode(ByteBuffer.wrap(b, 0, n), out, false)
        // not valid UTF-8: most Arabic files saved by old tools use Windows-1256
        return if (res.isError) Charset.forName("windows-1256") else Charsets.UTF_8
    }

    private fun sampleLines(b: ByteArray, n: Int, cs: Charset): List<String> {
        val text = String(b, 0, n, cs).removePrefix("\uFEFF")
        val parts = text.split("\r\n", "\n", "\r")
        val usable = if (n == b.size && parts.size > 1) parts.dropLast(1) else parts
        return usable.filter { it.isNotBlank() }.take(30)
    }

    private fun detectDelimiter(lines: List<String>): Char? {
        if (lines.isEmpty()) return null
        var best: Char? = null
        var bestScore = 0.0
        for (d in charArrayOf('\t', '|', ';', ',', ':')) {
            val counts = lines.map { l -> l.count { it == d } }
            val modal = counts.groupingBy { it }.eachCount().maxByOrNull { it.value } ?: continue
            if (modal.key == 0) continue
            val score = modal.value.toDouble() / counts.size
            if (score >= 0.7 && score > bestScore + 1e-9) {
                best = d
                bestScore = score
            }
        }
        return best
    }

    private fun splitLine(line: String, d: Char): List<String> {
        if (d == '\t' || d == '|' || d == ':') return line.split(d)
        // comma / semicolon: respect "quoted, values"
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            if (c == '"') {
                if (quoted && i + 1 < line.length && line[i + 1] == '"') {
                    sb.append('"')
                    i++
                } else {
                    quoted = !quoted
                }
            } else if (c == d && !quoted) {
                out.add(sb.toString())
                sb.setLength(0)
            } else {
                sb.append(c)
            }
            i++
        }
        out.add(sb.toString())
        return out
    }
}

// ---------------------------------------------------------------------------------------------
// SQLite (.db .sqlite ...)
// ---------------------------------------------------------------------------------------------

object SqliteEngine {
    fun search(ctx: Context, e: DataFile, needle: Needle, ctl: Ctl) {
        val file = Library.fileFor(ctx, e)
        val db = SQLiteDatabase.openDatabase(
            file.path, null,
            SQLiteDatabase.OPEN_READONLY or SQLiteDatabase.NO_LOCALIZED_COLLATORS
        )
        try {
            val tables = ArrayList<String>()
            val tc = db.rawQuery(
                "SELECT name FROM sqlite_master WHERE type IN ('table','view') " +
                    "AND name NOT LIKE 'sqlite_%' AND name NOT LIKE 'android_%'",
                null
            )
            try {
                while (tc.moveToNext()) tables.add(tc.getString(0))
            } finally {
                tc.close()
            }
            // the longest typed word is used to let SQLite pre-filter rows (much faster on big tables)
            val longest = needle.tokens.maxByOrNull { it[0].length }
            for (t in tables) {
                if (ctl.stop()) break
                scanTable(db, e, t, needle, ctl, longest)
            }
        } finally {
            db.close()
        }
    }

    private fun quote(id: String): String = "\"" + id.replace("\"", "\"\"") + "\""

    private fun escLike(s: String): String =
        s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    private fun scanTable(
        db: SQLiteDatabase,
        e: DataFile,
        t: String,
        needle: Needle,
        ctl: Ctl,
        longest: List<String>?
    ) {
        val q = quote(t)
        val cols = ArrayList<String>()
        val pc = db.rawQuery("PRAGMA table_info($q)", null)
        try {
            while (pc.moveToNext()) {
                val type = (pc.getString(2) ?: "").uppercase()
                if (!type.contains("BLOB")) cols.add(pc.getString(1))
            }
        } finally {
            pc.close()
        }

        var sql = "SELECT * FROM $q"
        val args = ArrayList<String>()
        if (longest != null && cols.isNotEmpty() && cols.size <= 300) {
            val expr = cols.joinToString(" || ' ' || ") { "COALESCE(" + quote(it) + ",'')" }
            sql += " WHERE " + longest.joinToString(" OR ") { "($expr) LIKE ? ESCAPE '\\'" }
            for (v in longest) args.add("%" + escLike(v) + "%")
        }

        val c = db.rawQuery(sql, args.toTypedArray())
        try {
            val n = c.columnCount
            val names = Array(n) { c.getColumnName(it) }
            val vals = Array(n) { "" }
            while (c.moveToNext()) {
                if (ctl.stop()) break
                ctl.scan()
                val sb = StringBuilder()
                for (i in 0 until n) {
                    val ty = c.getType(i)
                    if (ty == Cursor.FIELD_TYPE_NULL || ty == Cursor.FIELD_TYPE_BLOB) {
                        vals[i] = ""
                        continue
                    }
                    val v = c.getString(i) ?: ""
                    vals[i] = v
                    sb.append(v).append(' ')
                }
                if (!needle.matches(sb.toString())) continue
                val f = ArrayList<Pair<String, String>>()
                for (i in 0 until n) {
                    val v = vals[i].trim()
                    if (v.isNotEmpty()) f.add(names[i] to v)
                }
                if (f.isNotEmpty()) ctl.emit(Row(e.name, t, f))
            }
        } finally {
            c.close()
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Microsoft Access (.mdb .accdb .accdr .access) through the Jackcess library
// ---------------------------------------------------------------------------------------------

object AccessEngine {
    private val df = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    private fun str(v: Any?): String = when (v) {
        null -> ""
        is ByteArray -> ""
        is Array<*> -> ""
        is java.util.Date -> synchronized(df) { df.format(v) }
        else -> v.toString()
    }

    fun search(ctx: Context, e: DataFile, needle: Needle, ctl: Ctl) {
        val file = Library.fileFor(ctx, e)
        val db = DatabaseBuilder(file).setReadOnly(true).open()
        try {
            var ok = 0
            var lastErr: Exception? = null
            for (tn in db.tableNames) {
                if (ctl.stop()) break
                try {
                    val table = db.getTable(tn) ?: continue
                    for (row in table) {
                        if (ctl.stop()) break
                        ctl.scan()
                        val f = ArrayList<Pair<String, String>>()
                        val sb = StringBuilder()
                        for ((k, v) in row) {
                            val s = str(v).trim()
                            if (s.isEmpty()) continue
                            f.add(k to s)
                            sb.append(s).append(' ')
                        }
                        if (f.isNotEmpty() && needle.matches(sb.toString())) ctl.emit(Row(e.name, tn, f))
                    }
                    ok++
                } catch (ex: Exception) {
                    lastErr = ex
                }
            }
            val le = lastErr
            if (ok == 0 && le != null) throw le
        } finally {
            db.close()
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Excel .xlsx (read directly from the zip, streamed) and .xls (jxl library)
// ---------------------------------------------------------------------------------------------

object XlsxEngine {
    fun search(ctx: Context, e: DataFile, needle: Needle, ctl: Ctl) {
        val file = Library.fileFor(ctx, e)
        val zf = ZipFile(file)
        try {
            val shared = ArrayList<String>()
            val ss = zf.getEntry("xl/sharedStrings.xml")
            if (ss != null) {
                val ins = zf.getInputStream(ss)
                try {
                    parseShared(ins, shared)
                } finally {
                    ins.close()
                }
            }
            val colWord = ctx.getString(R.string.col)
            for ((name, path) in sheetList(zf)) {
                if (ctl.stop()) break
                val en = zf.getEntry(path) ?: continue
                val ins = zf.getInputStream(en)
                try {
                    scanSheet(ins, SheetFeeder(e.name, name, colWord, needle, ctl), shared, ctl)
                } finally {
                    ins.close()
                }
            }
        } finally {
            zf.close()
        }
    }

    private fun parseShared(input: InputStream, out: MutableList<String>) {
        val p = Xml.newPullParser()
        p.setInput(input, null)
        var sb: StringBuilder? = null
        var inT = false
        var inPh = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "si" -> sb = StringBuilder()
                    "t" -> inT = true
                    "rPh" -> inPh = true
                }
                XmlPullParser.TEXT -> if (inT && !inPh) sb?.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "t" -> inT = false
                    "rPh" -> inPh = false
                    "si" -> {
                        out.add(sb?.toString() ?: "")
                        sb = null
                    }
                }
            }
            ev = p.next()
        }
    }

    /** Sheet names and the zip path of each sheet, in workbook order. */
    private fun sheetList(zf: ZipFile): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        try {
            val rels = HashMap<String, String>()
            val re = zf.getEntry("xl/_rels/workbook.xml.rels")
            if (re != null) {
                val ins = zf.getInputStream(re)
                try {
                    val p = Xml.newPullParser()
                    p.setInput(ins, null)
                    var ev = p.eventType
                    while (ev != XmlPullParser.END_DOCUMENT) {
                        if (ev == XmlPullParser.START_TAG && p.name == "Relationship") {
                            val id = p.getAttributeValue(null, "Id")
                            val tg = p.getAttributeValue(null, "Target")
                            if (id != null && tg != null) {
                                rels[id] = if (tg.startsWith("/")) tg.substring(1) else "xl/$tg"
                            }
                        }
                        ev = p.next()
                    }
                } finally {
                    ins.close()
                }
            }
            val we = zf.getEntry("xl/workbook.xml")
            if (we != null) {
                val ins = zf.getInputStream(we)
                try {
                    val p = Xml.newPullParser()
                    p.setInput(ins, null)
                    var ev = p.eventType
                    while (ev != XmlPullParser.END_DOCUMENT) {
                        if (ev == XmlPullParser.START_TAG && p.name == "sheet") {
                            val nm = p.getAttributeValue(null, "name") ?: "Sheet"
                            var rid: String? = null
                            for (i in 0 until p.attributeCount) {
                                val an = p.getAttributeName(i)
                                if (an == "r:id" || an.endsWith(":id")) rid = p.getAttributeValue(i)
                            }
                            val target = if (rid != null) rels[rid] else null
                            if (target != null) out.add(nm to target)
                        }
                        ev = p.next()
                    }
                } finally {
                    ins.close()
                }
            }
        } catch (ex: Exception) {
            // fall back to the file names below
        }
        if (out.isEmpty()) {
            val names = ArrayList<String>()
            val en = zf.entries()
            while (en.hasMoreElements()) {
                val z = en.nextElement()
                if (z.name.startsWith("xl/worksheets/") && z.name.endsWith(".xml")) names.add(z.name)
            }
            names.sort()
            for (i in names.indices) out.add("Sheet ${i + 1}" to names[i])
        }
        return out
    }

    private fun colIndex(ref: String?): Int {
        if (ref == null) return -1
        var n = 0
        var any = false
        for (ch in ref) {
            val up = ch.uppercaseChar()
            if (up in 'A'..'Z') {
                n = n * 26 + (up - 'A' + 1)
                any = true
            } else {
                break
            }
        }
        return if (any) n - 1 else -1
    }

    private fun scanSheet(input: InputStream, feeder: SheetFeeder, shared: List<String>, ctl: Ctl) {
        val p = Xml.newPullParser()
        p.setInput(input, null)
        val cells = ArrayList<String>()
        val sb = StringBuilder()
        var type = ""
        var col = 0
        var inVal = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ctl.stop()) return
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "row" -> cells.clear()
                    "c" -> {
                        type = p.getAttributeValue(null, "t") ?: ""
                        val ci = colIndex(p.getAttributeValue(null, "r"))
                        col = if (ci >= 0) ci else cells.size
                        sb.setLength(0)
                    }
                    "v", "t" -> inVal = true
                }
                XmlPullParser.TEXT -> if (inVal) sb.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "v", "t" -> inVal = false
                    "c" -> {
                        val raw = sb.toString()
                        val value = when (type) {
                            "s" -> {
                                val ix = raw.trim().toIntOrNull()
                                if (ix != null && ix >= 0 && ix < shared.size) shared[ix] else raw
                            }
                            "b" -> if (raw.trim() == "1") "TRUE" else "FALSE"
                            else -> raw
                        }
                        while (cells.size <= col) cells.add("")
                        cells[col] = value
                    }
                    "row" -> {
                        ctl.scan()
                        feeder.feed(ArrayList(cells))
                    }
                }
            }
            ev = p.next()
        }
    }
}

object XlsEngine {
    fun search(ctx: Context, e: DataFile, needle: Needle, ctl: Ctl) {
        System.setProperty("jxl.nogc", "true")
        val file = Library.fileFor(ctx, e)
        val wb = jxl.Workbook.getWorkbook(file)
        try {
            val colWord = ctx.getString(R.string.col)
            for (sheet in wb.sheets) {
                if (ctl.stop()) break
                val feeder = SheetFeeder(e.name, sheet.name, colWord, needle, ctl)
                val rows = sheet.rows
                for (r in 0 until rows) {
                    if (ctl.stop()) break
                    ctl.scan()
                    val cells = sheet.getRow(r)
                    feeder.feed(cells.map { it.contents ?: "" })
                }
            }
        } finally {
            wb.close()
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Entry point used by the search screen
// ---------------------------------------------------------------------------------------------

object Engine {
    fun search(ctx: Context, e: DataFile, query: String, cancel: AtomicBoolean, sink: Sink): Ctl {
        val needle = Needle(query)
        val ctl = Ctl(cancel, Config.MAX_RESULTS, sink)
        if (needle.tokens.isEmpty()) return ctl
        when (e.fmt) {
            Fmt.SQLITE -> SqliteEngine.search(ctx, e, needle, ctl)
            Fmt.ACCESS -> AccessEngine.search(ctx, e, needle, ctl)
            Fmt.XLSX -> XlsxEngine.search(ctx, e, needle, ctl)
            Fmt.XLS -> XlsEngine.search(ctx, e, needle, ctl)
            Fmt.TEXT -> TextEngine.search(ctx, e, needle, ctl)
        }
        return ctl
    }
}
