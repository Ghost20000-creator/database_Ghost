package com.ghost.dataghost

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.DateFormat
import java.util.Date

class SavedActivity : Activity() {
    private lateinit var box: LinearLayout
    private lateinit var clearBtn: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.setPadding(dp(16), dp(12), dp(16), dp(8))

        clearBtn = label(getString(R.string.clear_all), 14f, Ui.RED, true)
        clearBtn.setPadding(dp(10), dp(8), dp(10), dp(8))
        clearBtn.setOnClickListener { confirmClear() }
        root.addView(header(getString(R.string.saved_title), clearBtn) { finish() })

        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(box)
        root.addView(sv, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)

        render()
    }

    private fun render() {
        box.removeAllViews()
        val items = Store.all(this).sortedByDescending { it.time }
        clearBtn.visibility = if (items.isEmpty()) View.INVISIBLE else View.VISIBLE
        if (items.isEmpty()) {
            val t = label(getString(R.string.saved_empty), 15f, Ui.MUTED)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(8), dp(48), dp(8), dp(8))
            box.addView(t, lp())
            return
        }
        for (s in items) box.addView(itemCard(s), lp(10))
    }

    private fun itemCard(s: SavedItem): LinearLayout {
        val c = card()
        c.addView(label(s.title, 14f, Ui.GREEN, true))
        c.addView(label(DateFormat.getDateTimeInstance().format(Date(s.time)), 11f, Ui.MUTED))

        val body = label(s.body, 14f, Ui.TEXT)
        body.maxLines = 6
        body.ellipsize = TextUtils.TruncateAt.END
        body.setPadding(0, dp(8), 0, dp(10))
        var expanded = false
        body.setOnClickListener {
            expanded = !expanded
            body.maxLines = if (expanded) Int.MAX_VALUE else 6
        }
        c.addView(body)

        val buttons = LinearLayout(this)
        buttons.orientation = LinearLayout.HORIZONTAL
        val copyB = button(getString(R.string.copy), Ui.GREEN, Color.BLACK, 13f, 8, 16)
        copyB.setOnClickListener { copyText(s.body) }
        val delB = button(getString(R.string.delete), Ui.RED, Color.WHITE, 13f, 8, 16)
        delB.setOnClickListener {
            Store.remove(this, s.id)
            render()
        }
        buttons.addView(copyB)
        val m = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        m.marginStart = dp(8)
        buttons.addView(delB, m)
        c.addView(buttons)
        return c
    }

    private fun confirmClear() {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setMessage(R.string.confirm_clear)
            .setPositiveButton(R.string.yes) { _, _ ->
                Store.clear(this)
                render()
            }
            .setNegativeButton(R.string.no, null)
            .show()
    }
}
