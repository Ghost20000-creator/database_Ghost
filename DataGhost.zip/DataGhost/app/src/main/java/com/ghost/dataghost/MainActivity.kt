package com.ghost.dataghost

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var savedBtn: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setBackgroundColor(Ui.BG)
        root.setPadding(dp(28), dp(48), dp(28), dp(16))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ghost_logo)
        root.addView(logo, LinearLayout.LayoutParams(dp(220), dp(220)))

        val title = label("Data Ghost", 32f, Ui.TEXT, true)
        title.gravity = Gravity.CENTER
        root.addView(title, lp(12))

        val tag = label(getString(R.string.tagline), 14f, Ui.MUTED)
        tag.gravity = Gravity.CENTER
        root.addView(tag, lp(6))

        val search = button(getString(R.string.btn_search), Ui.GREEN, Color.BLACK, 18f, 16)
        search.setOnClickListener { startActivity(Intent(this, FilesActivity::class.java)) }
        root.addView(search, lp(36))

        savedBtn = button(getString(R.string.btn_saved), Ui.SURFACE2, Ui.TEXT, 16f, 14)
        savedBtn.setOnClickListener { startActivity(Intent(this, SavedActivity::class.java)) }
        root.addView(savedBtn, lp(12))

        root.addView(View(this), LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))

        val ch = label(getString(R.string.channel), 13f, Ui.MUTED)
        ch.gravity = Gravity.CENTER
        ch.setPadding(dp(12), dp(10), dp(12), dp(10))
        ch.setOnClickListener { openChannel() }
        root.addView(ch)

        setContentView(root)

        val prefs = getSharedPreferences("ghost", MODE_PRIVATE)
        if (savedInstanceState == null &&
            (Config.GATE_EVERY_LAUNCH || !prefs.getBoolean("subscribed", false))
        ) {
            showGate()
        }
    }

    override fun onResume() {
        super.onResume()
        savedBtn.text = getString(R.string.btn_saved) + " (" + Store.all(this).size + ")"
    }

    private fun openChannel() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Config.CHANNEL_URL)))
        } catch (e: Exception) {
            Toast.makeText(this, Config.CHANNEL_URL, Toast.LENGTH_LONG).show()
        }
    }

    /** Subscribe prompt: Cancel closes the app, Subscribe opens the channel and lets the user in. */
    private fun showGate() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(dp(22), dp(22), dp(22), dp(18))
        box.background = rounded(Ui.SURFACE, 22, Ui.STROKE, 1)

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ghost_logo)
        box.addView(logo, LinearLayout.LayoutParams(dp(84), dp(84)))

        val t = label(getString(R.string.gate_title), 20f, Ui.TEXT, true)
        t.gravity = Gravity.CENTER
        box.addView(t, lp(12))

        val msg = label(getString(R.string.gate_msg), 15f, Ui.MUTED)
        msg.gravity = Gravity.CENTER
        box.addView(msg, lp(8))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val cancelBtn = button(getString(R.string.gate_cancel), Ui.RED, Color.WHITE, 16f, 12)
        val subscribeBtn = button(getString(R.string.gate_subscribe), Ui.GREEN, Color.BLACK, 16f, 12)
        cancelBtn.setOnClickListener {
            d.dismiss()
            finishAffinity()
        }
        subscribeBtn.setOnClickListener {
            getSharedPreferences("ghost", MODE_PRIVATE).edit().putBoolean("subscribed", true).apply()
            d.dismiss()
            openChannel()
        }
        row.addView(cancelBtn, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        val sp = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
        sp.marginStart = dp(10)
        row.addView(subscribeBtn, sp)
        box.addView(row, lp(22))

        d.setContentView(box)
        d.setCancelable(true)
        d.setCanceledOnTouchOutside(false)
        d.setOnCancelListener { finishAffinity() }
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.show()
        d.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.9f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT
        )
    }
}
