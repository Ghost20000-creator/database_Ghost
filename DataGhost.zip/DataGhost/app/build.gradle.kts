plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ghost.dataghost"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ghost.dataghost"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += listOf(
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "META-INF/DEPENDENCIES",
                "META-INF/INDEX.LIST"
            )
        }
    }

    lint {
        abortOnError = false
    }
}

dependencies {
    // Access databases: .mdb .accdb .accdr
    implementation("com.healthmarketscience.jackcess:jackcess:4.0.5")
    // Old Excel files: .xls
    implementation("net.sourceforge.jexcelapi:jxl:2.6.12") {
        exclude(group = "log4j")
    }
}
